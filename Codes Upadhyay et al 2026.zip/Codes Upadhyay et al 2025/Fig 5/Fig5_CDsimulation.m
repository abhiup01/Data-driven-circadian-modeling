% caluclating phases under various photoperiods (Large & Compect Wheat models)
clear all
close all

%
% Photoperiod = " 3 " 
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 3;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am3 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am3 = [0:0.1:96];                    
first_96_cal_am3 = deval(gen_sol_cal_po_am3, t_sel_am3);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am3 = (first_96_cal_am3(7,:)-min(first_96_cal_am3(7,:)))/(max(first_96_cal_am3(7,:))-min(first_96_cal_am3(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 3;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm3 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm3 = [0:0.1:96];                    
first_96_fog_fm3 = deval(gen_sol_fog_po_fm3, t_sel_fm3);

% ELF3 mRNA
norm_elf3_sim_fog_fm3 = (first_96_fog_fm3(19,:)-min(first_96_fog_fm3(19,:)))/(max(first_96_fog_fm3(19,:))-min(first_96_fog_fm3(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm3 = (first_96_fog_fm3(16,:)-min(first_96_fog_fm3(16,:)))/(max(first_96_fog_fm3(16,:))-min(first_96_fog_fm3(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm3 = (first_96_fog_fm3(22,:)-min(first_96_fog_fm3(22,:)))/(max(first_96_fog_fm3(22,:))-min(first_96_fog_fm3(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm3 = (first_96_fog_fm3(1,:)-min(first_96_fog_fm3(1,:)))/(max(first_96_fog_fm3(1,:))-min(first_96_fog_fm3(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am3);
per_normalday_am3 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am3);   
elf3_pam3 = mod(t_sel_am3(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm3);
per_normalday_fm3 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm3);    
elf3_pfm3 = mod(t_sel_fm3(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm3);   
elf4_pfm3 = mod(t_sel_fm3(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm3);    
lux_pfm3 = mod(t_sel_fm3(b(end)),24)





%
close all

%
% Photoperiod = " 6 "
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 6;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am6 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am6 = [0:0.1:96];                    
first_96_cal_am6 = deval(gen_sol_cal_po_am6, t_sel_am6);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am6 = (first_96_cal_am6(7,:)-min(first_96_cal_am6(7,:)))/(max(first_96_cal_am6(7,:))-min(first_96_cal_am6(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 6;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm6 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm6 = [0:0.1:96];                    
first_96_fog_fm6 = deval(gen_sol_fog_po_fm6, t_sel_fm6);

% ELF3 mRNA
norm_elf3_sim_fog_fm6 = (first_96_fog_fm6(19,:)-min(first_96_fog_fm6(19,:)))/(max(first_96_fog_fm6(19,:))-min(first_96_fog_fm6(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm6 = (first_96_fog_fm6(16,:)-min(first_96_fog_fm6(16,:)))/(max(first_96_fog_fm6(16,:))-min(first_96_fog_fm6(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm6 = (first_96_fog_fm6(22,:)-min(first_96_fog_fm6(22,:)))/(max(first_96_fog_fm6(22,:))-min(first_96_fog_fm6(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm6 = (first_96_fog_fm6(1,:)-min(first_96_fog_fm6(1,:)))/(max(first_96_fog_fm6(1,:))-min(first_96_fog_fm6(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am6);
per_normalday_am6 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am6);   
elf3_pam6 = mod(t_sel_am6(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm6);
per_normalday_fm6 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm6);    
elf3_pfm6 = mod(t_sel_fm6(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm6);   
elf4_pfm6 = mod(t_sel_fm6(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm6);    
lux_pfm6 = mod(t_sel_fm6(b(end)),24)





%
close all

%
% Photoperiod = " 9 "
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 9;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am9 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am9 = [0:0.1:96];                    
first_96_cal_am9 = deval(gen_sol_cal_po_am9, t_sel_am9);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am9 = (first_96_cal_am9(7,:)-min(first_96_cal_am9(7,:)))/(max(first_96_cal_am9(7,:))-min(first_96_cal_am9(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 9;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm9 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm9 = [0:0.1:96];                    
first_96_fog_fm9 = deval(gen_sol_fog_po_fm9, t_sel_fm9);

% ELF3 mRNA
norm_elf3_sim_fog_fm9 = (first_96_fog_fm9(19,:)-min(first_96_fog_fm9(19,:)))/(max(first_96_fog_fm9(19,:))-min(first_96_fog_fm9(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm9 = (first_96_fog_fm9(16,:)-min(first_96_fog_fm9(16,:)))/(max(first_96_fog_fm9(16,:))-min(first_96_fog_fm9(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm9 = (first_96_fog_fm9(22,:)-min(first_96_fog_fm9(22,:)))/(max(first_96_fog_fm9(22,:))-min(first_96_fog_fm9(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm9 = (first_96_fog_fm9(1,:)-min(first_96_fog_fm9(1,:)))/(max(first_96_fog_fm9(1,:))-min(first_96_fog_fm9(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am9);
per_normalday_am9 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am9);   
elf3_pam9 = mod(t_sel_am9(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm9);
per_normalday_fm9 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm9);    
elf3_pfm9 = mod(t_sel_fm9(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm9);   
elf4_pfm9 = mod(t_sel_fm9(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm9);    
lux_pfm9 = mod(t_sel_fm9(b(end)),24)




%
close all

%
% Photoperiod = " 12 "
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 12;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am12 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am12 = [0:0.1:96];                    
first_96_cal_am12 = deval(gen_sol_cal_po_am12, t_sel_am12);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am12 = (first_96_cal_am12(7,:)-min(first_96_cal_am12(7,:)))/(max(first_96_cal_am12(7,:))-min(first_96_cal_am12(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 12;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm12 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm12 = [0:0.1:96];                    
first_96_fog_fm12 = deval(gen_sol_fog_po_fm12, t_sel_fm12);

% ELF3 mRNA
norm_elf3_sim_fog_fm12 = (first_96_fog_fm12(19,:)-min(first_96_fog_fm12(19,:)))/(max(first_96_fog_fm12(19,:))-min(first_96_fog_fm12(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm12 = (first_96_fog_fm12(16,:)-min(first_96_fog_fm12(16,:)))/(max(first_96_fog_fm12(16,:))-min(first_96_fog_fm12(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm12 = (first_96_fog_fm12(22,:)-min(first_96_fog_fm12(22,:)))/(max(first_96_fog_fm12(22,:))-min(first_96_fog_fm12(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm12 = (first_96_fog_fm12(1,:)-min(first_96_fog_fm12(1,:)))/(max(first_96_fog_fm12(1,:))-min(first_96_fog_fm12(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am12);
per_normalday_am12 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am12);   
elf3_pam12 = mod(t_sel_am12(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm12);
per_normalday_fm12 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm12);    
elf3_pfm12 = mod(t_sel_fm12(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm12);   
elf4_pfm12 = mod(t_sel_fm12(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm12);    
lux_pfm12 = mod(t_sel_fm12(b(end)),24)




%
close all

%
% Photoperiod = " 15 "
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 15;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am15 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am15 = [0:0.1:96];                    
first_96_cal_am15 = deval(gen_sol_cal_po_am15, t_sel_am15);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am15 = (first_96_cal_am15(7,:)-min(first_96_cal_am15(7,:)))/(max(first_96_cal_am15(7,:))-min(first_96_cal_am15(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 15;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm15 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm15 = [0:0.1:96];                    
first_96_fog_fm15 = deval(gen_sol_fog_po_fm15, t_sel_fm15);

% ELF3 mRNA
norm_elf3_sim_fog_fm15 = (first_96_fog_fm15(19,:)-min(first_96_fog_fm15(19,:)))/(max(first_96_fog_fm15(19,:))-min(first_96_fog_fm15(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm15 = (first_96_fog_fm15(16,:)-min(first_96_fog_fm15(16,:)))/(max(first_96_fog_fm15(16,:))-min(first_96_fog_fm15(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm15 = (first_96_fog_fm15(22,:)-min(first_96_fog_fm15(22,:)))/(max(first_96_fog_fm15(22,:))-min(first_96_fog_fm15(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm15 = (first_96_fog_fm15(1,:)-min(first_96_fog_fm15(1,:)))/(max(first_96_fog_fm15(1,:))-min(first_96_fog_fm15(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am15);
per_normalday_am15 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am15);   
elf3_pam15 = mod(t_sel_am15(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm15);
per_normalday_fm15 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm15);    
elf3_pfm15 = mod(t_sel_fm15(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm15);   
elf4_pfm15 = mod(t_sel_fm15(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm15);    
lux_pfm15 = mod(t_sel_fm15(b(end)),24)




%
close all

%
% Photoperiod = " 18 "
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 18;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am18 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am18 = [0:0.1:96];                    
first_96_cal_am18 = deval(gen_sol_cal_po_am18, t_sel_am18);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am18 = (first_96_cal_am18(7,:)-min(first_96_cal_am18(7,:)))/(max(first_96_cal_am18(7,:))-min(first_96_cal_am18(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 18;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm18 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm18 = [0:0.1:96];                    
first_96_fog_fm18 = deval(gen_sol_fog_po_fm18, t_sel_fm18);

% ELF3 mRNA
norm_elf3_sim_fog_fm18 = (first_96_fog_fm18(19,:)-min(first_96_fog_fm18(19,:)))/(max(first_96_fog_fm18(19,:))-min(first_96_fog_fm18(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm18 = (first_96_fog_fm18(16,:)-min(first_96_fog_fm18(16,:)))/(max(first_96_fog_fm18(16,:))-min(first_96_fog_fm18(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm18 = (first_96_fog_fm18(22,:)-min(first_96_fog_fm18(22,:)))/(max(first_96_fog_fm18(22,:))-min(first_96_fog_fm18(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm18 = (first_96_fog_fm18(1,:)-min(first_96_fog_fm18(1,:)))/(max(first_96_fog_fm18(1,:))-min(first_96_fog_fm18(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am18);
per_normalday_am18 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am18);   
elf3_pam18 = mod(t_sel_am18(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm18);
per_normalday_fm18 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm18);    
elf3_pfm18 = mod(t_sel_fm18(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm18);   
elf4_pfm18 = mod(t_sel_fm18(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm18);    
lux_pfm18 = mod(t_sel_fm18(b(end)),24)





%
close all

%
% Photoperiod = " 21 "
%

CLm_init = 0; 
CLp_init = 0; 
P_init = 0; 
P97m_init = 0; 
P97p_init = 0; 
T1P5m_init = 0; 
T1P5p_init = 0; 
ELm_init = 0; 
ELp_init = 0; 
init_cond_a_c = [CLm_init,CLp_init,P97m_init,P97p_init,T1P5m_init,T1P5p_init,ELm_init,ELp_init,P_init];

T=24;        
pp = 21;       
LDLD_or_LDLL = "LDLD";
t_end = 480; 
[~,v_ldld_a] = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_a_c);
init_cond_upd_a_c = v_ldld_a(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_cal_po_am21 = ode15s(@(t,vars)arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL),[0,t_end_final],init_cond_upd_a_c);
t_sel_am21 = [0:0.1:96];                    
first_96_cal_am21 = deval(gen_sol_cal_po_am21, t_sel_am21);

% EL: ELF4/LUX proxy to ELF3 :: arabidopsis model normal day :: amnd
norm_el_sim_cal_am21 = (first_96_cal_am21(7,:)-min(first_96_cal_am21(7,:)))/(max(first_96_cal_am21(7,:))-min(first_96_cal_am21(7,:)));


%
% Fogelamark Arabidopsis model 
%
[parms_og init_cond_wt] = FogelmarkModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 21;
LDLD_or_LDLL = "LDLD"; 
t_end = 480;
[~,v_ldld_a_l] = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_updl = v_ldld_a_l(end,:);
t_end_final = 96;
LDLD_or_LDLL = "LDLD";
gen_sol_fog_po_fm21 = ode15s(@(t,vars)arabidopsis_fogelmark(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end_final],init_conditions_updl);
t_sel_fm21 = [0:0.1:96];                    
first_96_fog_fm21 = deval(gen_sol_fog_po_fm21, t_sel_fm21);

% ELF3 mRNA
norm_elf3_sim_fog_fm21 = (first_96_fog_fm21(19,:)-min(first_96_fog_fm21(19,:)))/(max(first_96_fog_fm21(19,:))-min(first_96_fog_fm21(19,:)));
% ELF4 mRNA
norm_elf4_sim_fog_fm21 = (first_96_fog_fm21(16,:)-min(first_96_fog_fm21(16,:)))/(max(first_96_fog_fm21(16,:))-min(first_96_fog_fm21(16,:)));
% LUX mRNA
norm_lux_sim_fog_fm21 = (first_96_fog_fm21(22,:)-min(first_96_fog_fm21(22,:)))/(max(first_96_fog_fm21(22,:))-min(first_96_fog_fm21(22,:)));
% LHY mRNA
norm_lhy_sim_fog_fm21 = (first_96_fog_fm21(1,:)-min(first_96_fog_fm21(1,:)))/(max(first_96_fog_fm21(1,:))-min(first_96_fog_fm21(1,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_el_sim_cal_am21);
per_normalday_am21 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_el_sim_cal_am21);   
elf3_pam21 = mod(t_sel_am21(b(end)),24)

% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_fog_fm21);
per_normalday_fm21 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_fog_fm21);    
elf3_pfm21 = mod(t_sel_fm21(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_fog_fm21);   
elf4_pfm21 = mod(t_sel_fm21(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_fog_fm21);    
lux_pfm21 = mod(t_sel_fm21(b(end)),24)




%
% Fig-5C.pdf

% Arabidopsis Caluwe model : EC complex : photoperiods 
caluwe_photoperiods = ["3", "6", "9", "12", "15", "18", "21"]

elf3_pam15 = 8.8; % corrected phase due to: findpeaks(norm_el_sim_cal_am15)

% pp phases
ca_3_ec = [elf3_pam3]
ca_6_ec = [elf3_pam6]          % [el]
ca_9_ec = [elf3_pam9]
ca_12_ec = [elf3_pam12]
ca_15_ec = [elf3_pam15]         
ca_18_ec = [elf3_pam18]
ca_21_ec = [elf3_pam21]

pp = [1 1 1;    
    2 2 2;
    3 3 3;
    4 4 4;
    5 5 5;
    6 6 6;
    7 7 7];


plot(pp(1,1), ca_3_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 

plot(pp(2,1), ca_6_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 

plot(pp(3,1), ca_9_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 

plot(pp(4,1), ca_12_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 

plot(pp(5,1), ca_15_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 

plot(pp(6,1), ca_18_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 

plot(pp(7,1), ca_21_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','c', 'MarkerEdgeColor','c')
hold on 
legend({'ELF4/LUX'}, FontSize=12)

xlim([0 8]);
xticks([0, 1, 2, 3, 4, 5, 6, 7, 8]);
xticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'}); % photoperiods
ax = gca;
ax.FontSize = 18; 
xtickangle(45);
xlabel('Photoperiods (hours)', FontSize=18);
ylim([0 24]);
yticks([0, 3, 6, 9, 12, 15, 18, 21, 24]);
yticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'});
ay = gca;
ay.FontSize = 18; 
ylabel('Phases (hours from dawn)', FontSize=18);

sgtitle("Caluwe model ({\itArabidopsis})", FontSize=18);

grid on

saveas(gcf,'Fig-5C.pdf') 





%
% Fig-5D.pdf

figure

% Fogelamrk Arabidopsis model : EC complex : photoperiods 

% pp phases
fo_3_ec = [elf3_pfm3 elf4_pfm3 lux_pfm3]
fo_6_ec = [elf3_pfm6 elf4_pfm6 lux_pfm6]          % [elf3 elf4 lux]
fo_9_ec = [elf3_pfm9 elf4_pfm9 lux_pfm9]
fo_12_ec = [elf3_pfm12 elf4_pfm12 lux_pfm12]
fo_15_ec = [elf3_pfm15 elf4_pfm15 lux_pfm15]          % [elf3 elf4 lux]
fo_18_ec = [elf3_pfm18 elf4_pfm18 lux_pfm18]
fo_21_ec = [elf3_pfm21 elf4_pfm21 lux_pfm21]

pp = [1 1 1;    
    2 2 2;
    3 3 3;
    4 4 4;
    5 5 5;
    6 6 6;
    7 7 7];

plot(pp(1,1), fo_3_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(1,2), fo_3_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(1,3), fo_3_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(2,1), fo_6_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(2,2), fo_6_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(2,3), fo_6_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(3,1), fo_9_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(3,2), fo_9_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(3,3), fo_9_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(4,1), fo_12_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(4,2), fo_12_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(4,3), fo_12_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(5,1), fo_15_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(5,2), fo_15_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(5,3), fo_15_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(6,1), fo_18_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(6,2), fo_18_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(6,3), fo_18_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(7,1), fo_21_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(7,2), fo_21_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(7,3), fo_21_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 
legend({'ELF3' 'ELF4' 'LUX'}, FontSize=12)

xlim([0 8]);
xticks([0, 1, 2, 3, 4, 5, 6, 7, 8]);
xticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'}); % photoperiods
ax = gca;
ax.FontSize = 18; 
xtickangle(45);
xlabel('Photoperiods (hours)', FontSize=18);
ylim([0 24]);
yticks([0, 3, 6, 9, 12, 15, 18, 21, 24]);
yticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'});
ay = gca;
ay.FontSize = 18; 
ylabel('Phases (hours from dawn)', FontSize=18);

sgtitle("Fogelmark model ({\itArabidopsis})", FontSize=18);

grid on

saveas(gcf,'Fig-5D.pdf') 





