# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs Wheat and Arabidopsis clock models simulations under various photoperiods for Figure 5.


## Usage
Run the main scripts in Fig5_ABsimulation.m and Fig5_CDsimulation.m in MATLAB.


## Features
- Two wheat clock models (compact and large) equations are written in wheat_wt_compact_abhi.m and wheat_large_abhi.m 
- Model's parameters and variable's initial conditions are called from CompactModel_Parameters_InitialCond.m and LargeModel_Parameters_InitialCond.m
- Two arabidopsis clock models (caluwe and fogelmark) equations and initial conditions, parameters are written in arabidopsis_caluwe.m ,  arabidopsis_fogelmark.m and FogelmarkModel_Parameters_InitialCond.m


## Output
Fig-5A.pdf, Fig-5B.pdf, Fig-5C.pdf and Fig-5D.pdf for models of wheat circadian oscillators predict ELF3 peaks at dawn in comparison to dusk peaking in arabidopsis for a range of photoperiodsare are generated.

 
