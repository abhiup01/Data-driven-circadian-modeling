function solutions = arabidopsis_caluwe(t,vars,pp,T,LDLD_or_LDLL)


if(LDLD_or_LDLL == "LDLD")

  if rem(t, T) < pp   % pp: photoperiod % T cycle (daylength) circadian 24 hrs by default
    L = 1;
    D = 0;
  else
    L = 0;
    D = 1;
  end  
        
elseif(LDLD_or_LDLL == "LDLL")  
    L = 1;
    D = 0;
end 


%% Parameters

par_v1 = 4.58; %4.6
par_v1L = 3.0;
par_v2A = 1.27; %1.3
par_v2L = 5.0; 
par_v3 = 1.0;
par_v4 = 1.47; %1.5
par_k1L = 0.53; 
par_k1D = 0.21; 
par_k2 = 0.35;
par_k3 = 0.56;
par_k4 = 0.57;
par_p1 = 0.76;
par_p1L = 0.42;
par_p2 = 1.01; %1
par_p3 = 0.64;
par_p4 = 1.01; %1
par_d1 = 0.68;
par_d2D = 0.5;
par_d2L = 0.29; %0.3
par_d3D = 0.48;
par_d3L = 0.38; %0.78 (big change)
par_d4D = 1.21; % 1.21 (original)
par_d4L = 0.38; % 0.38 (original)
par_K0 = 2.80;  %new (big change)
par_K1 = 0.16;
par_K2 = 1.18; %1.2
par_K4 = 0.28; %0.23 (change)
par_K5 = 0.57; %0.30 (change)
par_K5b = 1.73; %new (big change)
par_K6 = 0.46; 
par_K7 = 2.0; 
par_K8 = 0.36;
par_K9 = 1.9;
par_K10 = 1.9;

%% Variables

CL_m = vars(1); % CL (CAA1/LHY) mrna
CL_p = vars(2); % CL protein 
P97_m = vars(3); % P97 (PRR9/7) mrna 
P97_p = vars(4); % P97 protein
P51_m = vars(5); % P51 (PRR5/TOC1) mrna
P51_p = vars(6); % P51 (PRR5/TOC1) protein 
EL_m = vars(7); % EL (ELF4/LUX) mrna 
EL_p = vars(8); % EL protein 
P_p = vars(9); % P (unknown protein involved in light activation of the clock) protein 

%% Non-ODEs

EC = 3*EL_p;

%% ODEs

% Change in CL mRNA
dCL_m = (par_v1+par_v1L*L*P_p)/(1+(CL_p/par_K0)^2+(P97_p/par_K1)^2+(P51_p/par_K2)^2) - ( ...
    par_k1L*L+par_k1D*D)*CL_m;
% Change in CL protein 
dCL_p = (par_p1+par_p1L*L)*CL_m - par_d1*CL_p;
% Change in P97 mRNA
dP97_m = (par_v2L*L*P_p+par_v2A)/(1+(P51_p/par_K4)^2+(EC/par_K5)^2+(CL_p/par_K5b)^2) - ( ...
    par_k2*P97_m);
% Change in P97 protein 
dP97_p = par_p2*P97_m - (par_d2D*D+par_d2L*L)*P97_p;
% Change in P51 mRNA
dP51_m = par_v3/(1+(CL_p/par_K6)^2+(P51_p/par_K7)^2) - par_k3*P51_m;
% Change in P51 protein
dP51_p = par_p3*P51_m - (par_d3D*D+par_d3L*L)*P51_p;
% Change in EL mRNA 
dEL_m = (L*par_v4)/(1+(CL_p/par_K8)^2+(P51_p/par_K9)^2+(EC/par_K10)^2) - ( ...
    par_k4*EL_m);
% Change in EL protein
dEL_p = par_p4*EL_m - (par_d4D*D+par_d4L*L)*EL_p;
% Change in P protein 
dP_p = 0.3*(1-P_p)*D - P_p*L;

%%
solutions = [dCL_m;dCL_p;dP97_m;dP97_p;dP51_m;dP51_p;dEL_m;dEL_p;dP_p];

end 