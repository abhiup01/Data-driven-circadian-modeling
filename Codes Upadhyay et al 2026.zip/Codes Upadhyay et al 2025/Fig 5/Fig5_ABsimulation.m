% caluclating phases under various photoperiods (Large & Compect Wheat models)

clear all
close all

%
% Photoperiod = " 3 " 
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 3;      % 3: photoperiod 3:21, for example: long days 16:8, pp = 16
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm3 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm3 = [0:0.1:96];                    
first_96_cm3 = deval(gen_sol_po_cm3, t_sel_cm3);


% compact model photoperiod 3 :: cm3
% "min-max normalization" of simulations
norm_lhy_sim_cm3 = (first_96_cm3(1,:)-min(first_96_cm3(1,:)))/(max(first_96_cm3(1,:))-min(first_96_cm3(1,:)));       % po: post-optimization
norm_elf3_sim_cm3 = (first_96_cm3(14,:)-min(first_96_cm3(14,:)))/(max(first_96_cm3(14,:))-min(first_96_cm3(14,:)));
norm_lux_sim_cm3 = (first_96_cm3(12,:)-min(first_96_cm3(12,:)))/(max(first_96_cm3(12,:))-min(first_96_cm3(12,:))); 
norm_prr73_sim_cm3 = (first_96_cm3(6,:)-min(first_96_cm3(6,:)))/(max(first_96_cm3(6,:))-min(first_96_cm3(6,:)));
norm_p5t1_sim_cm3 = (first_96_cm3(8,:)-min(first_96_cm3(8,:)))/(max(first_96_cm3(8,:))-min(first_96_cm3(8,:)));
norm_elf4_sim_cm3 = (first_96_cm3(10,:)-min(first_96_cm3(10,:)))/(max(first_96_cm3(10,:))-min(first_96_cm3(10,:)));


%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 3;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm3 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm3 = [0:0.1:96];                    
first_96_lm3 = deval(gen_sol_po_lm3, t_sel_lm3);

% large model normal day :: lmnd
norm_lhy_sim_lm3 = (first_96_lm3(1,:)-min(first_96_lm3(1,:)))/(max(first_96_lm3(1,:))-min(first_96_lm3(1,:)));       % po: post-optimization
norm_elf3_sim_lm3 = (first_96_lm3(19,:)-min(first_96_lm3(19,:)))/(max(first_96_lm3(19,:))-min(first_96_lm3(19,:)));
norm_gi_sim_lm3 = (first_96_lm3(29,:)-min(first_96_lm3(29,:)))/(max(first_96_lm3(29,:))-min(first_96_lm3(29,:))); 
norm_lux_sim_lm3 = (first_96_lm3(22,:)-min(first_96_lm3(22,:)))/(max(first_96_lm3(22,:))-min(first_96_lm3(22,:))); 
norm_prr73_sim_lm3 = (first_96_lm3(8,:)-min(first_96_lm3(8,:)))/(max(first_96_lm3(8,:))-min(first_96_lm3(8,:)));
norm_p5t1_sim_lm3 = (first_96_lm3(13,:)-min(first_96_lm3(13,:)))/(max(first_96_lm3(13,:))-min(first_96_lm3(13,:)));
norm_elf4_sim_lm3 = (first_96_lm3(16,:)-min(first_96_lm3(16,:)))/(max(first_96_lm3(16,:))-min(first_96_lm3(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm3);
per_normalday_cm3 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm3); 
c = abs(t_sel_cm3(b(end))-t_sel_cm3(b(end-1)));
if c < 24 & (a(end-1)>a(end))
    elf3_pcm3 = mod(t_sel_cm3(b(end-1)),24)
else
elf3_pcm3 = mod(t_sel_cm3(b(end)),24)
end
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm3);   
elf4_pcm3 = mod(t_sel_cm3(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm3);    
lux_pcm3 = mod(t_sel_cm3(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm3);
per_normalday_lm3 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm3);    
elf3_plm3 = mod(t_sel_lm3(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm3);   
elf4_plm3 = mod(t_sel_lm3(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_lm3);    
lux_plm3 = mod(t_sel_lm3(b(end)),24)





%
close all

%
% Photoperiod = " 6 "
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 6;      % Normal Day: photoperiod 12:12, for example: long days 16:8, pp = 16
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm6 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm6 = [0:0.1:96];                    
first_96_cm6 = deval(gen_sol_po_cm6, t_sel_cm6);


% compact model photoperiod 3 :: cm3
% "min-max normalization" of simulations
norm_lhy_sim_cm6 = (first_96_cm6(1,:)-min(first_96_cm6(1,:)))/(max(first_96_cm6(1,:))-min(first_96_cm6(1,:)));       % po: post-optimization
norm_elf3_sim_cm6 = (first_96_cm6(14,:)-min(first_96_cm6(14,:)))/(max(first_96_cm6(14,:))-min(first_96_cm6(14,:)));
norm_lux_sim_cm6 = (first_96_cm6(12,:)-min(first_96_cm6(12,:)))/(max(first_96_cm6(12,:))-min(first_96_cm6(12,:))); 
norm_prr73_sim_cm6 = (first_96_cm6(6,:)-min(first_96_cm6(6,:)))/(max(first_96_cm6(6,:))-min(first_96_cm6(6,:)));
norm_p5t1_sim_cm6 = (first_96_cm6(8,:)-min(first_96_cm6(8,:)))/(max(first_96_cm6(8,:))-min(first_96_cm6(8,:)));
norm_elf4_sim_cm6 = (first_96_cm6(10,:)-min(first_96_cm6(10,:)))/(max(first_96_cm6(10,:))-min(first_96_cm6(10,:)));


%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 6;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm6 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm6 = [0:0.1:96];                    
first_96_lm6 = deval(gen_sol_po_lm6, t_sel_lm6);

% large model normal day :: lmnd
norm_lhy_sim_lm6 = (first_96_lm6(1,:)-min(first_96_lm6(1,:)))/(max(first_96_lm6(1,:))-min(first_96_lm6(1,:)));       % po: post-optimization
norm_elf3_sim_lm6 = (first_96_lm6(19,:)-min(first_96_lm6(19,:)))/(max(first_96_lm6(19,:))-min(first_96_lm6(19,:)));
norm_gi_sim_lm6 = (first_96_lm6(29,:)-min(first_96_lm6(29,:)))/(max(first_96_lm6(29,:))-min(first_96_lm6(29,:))); 
norm_lux_sim_lm6 = (first_96_lm6(22,:)-min(first_96_lm6(22,:)))/(max(first_96_lm6(22,:))-min(first_96_lm6(22,:))); 
norm_prr73_sim_lm6 = (first_96_lm6(8,:)-min(first_96_lm6(8,:)))/(max(first_96_lm6(8,:))-min(first_96_lm6(8,:)));
norm_p5t1_sim_lm6 = (first_96_lm6(13,:)-min(first_96_lm6(13,:)))/(max(first_96_lm6(13,:))-min(first_96_lm6(13,:)));
norm_elf4_sim_lm6 = (first_96_lm6(16,:)-min(first_96_lm6(16,:)))/(max(first_96_lm6(16,:))-min(first_96_lm6(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm6);
per_normalday_cm6 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm6);   
elf3_pcm6 = mod(t_sel_cm6(b(end)),24)
%elf3_phase_normalday_com = mod(t_sel(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm6);   
elf4_pcm6 = mod(t_sel_cm6(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm6);    
lux_pcm6 = mod(t_sel_cm6(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm6);
per_normalday_lm6 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm6);    
elf3_plm6 = mod(t_sel_lm6(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm6);   
elf4_plm6 = mod(t_sel_lm6(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_lm6);    
lux_plm6 = mod(t_sel_lm6(b(end)),24)





%
close all

%
% Photoperiod = " 9 "
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 9;      
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm9 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm9 = [0:0.1:96];                    
first_96_cm9 = deval(gen_sol_po_cm9, t_sel_cm9);

% "min-max normalization" of simulations
norm_lhy_sim_cm9 = (first_96_cm9(1,:)-min(first_96_cm9(1,:)))/(max(first_96_cm9(1,:))-min(first_96_cm9(1,:)));       % po: post-optimization
norm_elf3_sim_cm9 = (first_96_cm9(14,:)-min(first_96_cm9(14,:)))/(max(first_96_cm9(14,:))-min(first_96_cm9(14,:)));
norm_lux_sim_cm9 = (first_96_cm9(12,:)-min(first_96_cm9(12,:)))/(max(first_96_cm9(12,:))-min(first_96_cm9(12,:))); 
norm_prr73_sim_cm9 = (first_96_cm9(6,:)-min(first_96_cm9(6,:)))/(max(first_96_cm9(6,:))-min(first_96_cm9(6,:)));
norm_p5t1_sim_cm9 = (first_96_cm9(8,:)-min(first_96_cm9(8,:)))/(max(first_96_cm9(8,:))-min(first_96_cm9(8,:)));
norm_elf4_sim_cm9 = (first_96_cm9(10,:)-min(first_96_cm9(10,:)))/(max(first_96_cm9(10,:))-min(first_96_cm9(10,:)));

%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 9;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm9 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm9 = [0:0.1:96];                    
first_96_lm9 = deval(gen_sol_po_lm9, t_sel_lm9);

norm_lhy_sim_lm9 = (first_96_lm9(1,:)-min(first_96_lm9(1,:)))/(max(first_96_lm9(1,:))-min(first_96_lm9(1,:)));       % po: post-optimization
norm_elf3_sim_lm9 = (first_96_lm9(19,:)-min(first_96_lm9(19,:)))/(max(first_96_lm9(19,:))-min(first_96_lm9(19,:)));
norm_gi_sim_lm9 = (first_96_lm9(29,:)-min(first_96_lm9(29,:)))/(max(first_96_lm9(29,:))-min(first_96_lm9(29,:))); 
norm_lux_sim_lm9 = (first_96_lm9(22,:)-min(first_96_lm9(22,:)))/(max(first_96_lm9(22,:))-min(first_96_lm9(22,:))); 
norm_prr73_sim_lm9 = (first_96_lm9(8,:)-min(first_96_lm9(8,:)))/(max(first_96_lm9(8,:))-min(first_96_lm9(8,:)));
norm_p5t1_sim_lm9 = (first_96_lm9(13,:)-min(first_96_lm9(13,:)))/(max(first_96_lm9(13,:))-min(first_96_lm9(13,:)));
norm_elf4_sim_lm9 = (first_96_lm9(16,:)-min(first_96_lm9(16,:)))/(max(first_96_lm9(16,:))-min(first_96_lm9(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm9);
per_normalday_cm9 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm9);   
elf3_pcm9 = mod(t_sel_cm9(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm9);   
elf4_pcm9 = mod(t_sel_cm9(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm9);    
lux_pcm9 = mod(t_sel_cm9(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm9);
per_normalday_lm9 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm9);    
elf3_plm9 = mod(t_sel_lm9(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm9);   
elf4_plm9 = mod(t_sel_lm9(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_lm9);    
lux_plm9 = mod(t_sel_lm9(b(end)),24)



%
close all

%
% Photoperiod = " 12 "
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 12;      
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm12 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm12 = [0:0.1:96];                    
first_96_cm12 = deval(gen_sol_po_cm12, t_sel_cm12);

% "min-max normalization" of simulations
norm_lhy_sim_cm12 = (first_96_cm12(1,:)-min(first_96_cm12(1,:)))/(max(first_96_cm12(1,:))-min(first_96_cm12(1,:)));       % po: post-optimization
norm_elf3_sim_cm12 = (first_96_cm12(14,:)-min(first_96_cm12(14,:)))/(max(first_96_cm12(14,:))-min(first_96_cm12(14,:)));
norm_lux_sim_cm12 = (first_96_cm12(12,:)-min(first_96_cm12(12,:)))/(max(first_96_cm12(12,:))-min(first_96_cm12(12,:))); 
norm_prr73_sim_cm12 = (first_96_cm12(6,:)-min(first_96_cm12(6,:)))/(max(first_96_cm12(6,:))-min(first_96_cm12(6,:)));
norm_p5t1_sim_cm12 = (first_96_cm12(8,:)-min(first_96_cm12(8,:)))/(max(first_96_cm12(8,:))-min(first_96_cm12(8,:)));
norm_elf4_sim_cm12 = (first_96_cm12(10,:)-min(first_96_cm12(10,:)))/(max(first_96_cm12(10,:))-min(first_96_cm12(10,:)));

%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 12;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm12 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm12 = [0:0.1:96];                    
first_96_lm12 = deval(gen_sol_po_lm12, t_sel_lm12);

norm_lhy_sim_lm12 = (first_96_lm12(1,:)-min(first_96_lm12(1,:)))/(max(first_96_lm12(1,:))-min(first_96_lm12(1,:)));       % po: post-optimization
norm_elf3_sim_lm12 = (first_96_lm12(19,:)-min(first_96_lm12(19,:)))/(max(first_96_lm12(19,:))-min(first_96_lm12(19,:)));
norm_gi_sim_lm12 = (first_96_lm12(29,:)-min(first_96_lm12(29,:)))/(max(first_96_lm12(29,:))-min(first_96_lm12(29,:))); 
norm_lux_sim_lm12 = (first_96_lm12(22,:)-min(first_96_lm12(22,:)))/(max(first_96_lm12(22,:))-min(first_96_lm12(22,:))); 
norm_prr73_sim_lm12 = (first_96_lm12(8,:)-min(first_96_lm12(8,:)))/(max(first_96_lm12(8,:))-min(first_96_lm12(8,:)));
norm_p5t1_sim_lm12 = (first_96_lm12(13,:)-min(first_96_lm12(13,:)))/(max(first_96_lm12(13,:))-min(first_96_lm12(13,:)));
norm_elf4_sim_lm12 = (first_96_lm12(16,:)-min(first_96_lm12(16,:)))/(max(first_96_lm12(16,:))-min(first_96_lm12(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm12);
per_normalday_cm12 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm12);   
elf3_pcm12 = mod(t_sel_cm12(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm12);   
elf4_pcm12 = mod(t_sel_cm12(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm12);    
lux_pcm12 = mod(t_sel_cm12(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm12);
per_normalday_lm12 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm12);    
elf3_plm12 = mod(t_sel_lm12(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm12);   
elf4_plm12 = mod(t_sel_lm12(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_lm12);    
lux_plm12 = mod(t_sel_lm12(b(end)),24)



%
close all

%
% Photoperiod = " 15 "
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 15;      
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm15 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm15 = [0:0.1:96];                    
first_96_cm15 = deval(gen_sol_po_cm15, t_sel_cm15);

% "min-max normalization" of simulations
norm_lhy_sim_cm15 = (first_96_cm15(1,:)-min(first_96_cm15(1,:)))/(max(first_96_cm15(1,:))-min(first_96_cm15(1,:)));       % po: post-optimization
norm_elf3_sim_cm15 = (first_96_cm15(14,:)-min(first_96_cm15(14,:)))/(max(first_96_cm15(14,:))-min(first_96_cm15(14,:)));
norm_lux_sim_cm15 = (first_96_cm15(12,:)-min(first_96_cm15(12,:)))/(max(first_96_cm15(12,:))-min(first_96_cm15(12,:))); 
norm_prr73_sim_cm15 = (first_96_cm15(6,:)-min(first_96_cm15(6,:)))/(max(first_96_cm15(6,:))-min(first_96_cm15(6,:)));
norm_p5t1_sim_cm15 = (first_96_cm15(8,:)-min(first_96_cm15(8,:)))/(max(first_96_cm15(8,:))-min(first_96_cm15(8,:)));
norm_elf4_sim_cm15 = (first_96_cm15(10,:)-min(first_96_cm15(10,:)))/(max(first_96_cm15(10,:))-min(first_96_cm15(10,:)));

%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 15;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm15 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm15 = [0:0.1:96];                    
first_96_lm15 = deval(gen_sol_po_lm15, t_sel_lm15);

norm_lhy_sim_lm15 = (first_96_lm15(1,:)-min(first_96_lm15(1,:)))/(max(first_96_lm15(1,:))-min(first_96_lm15(1,:)));       % po: post-optimization
norm_elf3_sim_lm15 = (first_96_lm15(19,:)-min(first_96_lm15(19,:)))/(max(first_96_lm15(19,:))-min(first_96_lm15(19,:)));
norm_gi_sim_lm15 = (first_96_lm15(29,:)-min(first_96_lm15(29,:)))/(max(first_96_lm15(29,:))-min(first_96_lm15(29,:))); 
norm_lux_sim_lm15 = (first_96_lm15(22,:)-min(first_96_lm15(22,:)))/(max(first_96_lm15(22,:))-min(first_96_lm15(22,:))); 
norm_prr73_sim_lm15 = (first_96_lm15(8,:)-min(first_96_lm15(8,:)))/(max(first_96_lm15(8,:))-min(first_96_lm15(8,:)));
norm_p5t1_sim_lm15 = (first_96_lm15(13,:)-min(first_96_lm15(13,:)))/(max(first_96_lm15(13,:))-min(first_96_lm15(13,:)));
norm_elf4_sim_lm15 = (first_96_lm15(16,:)-min(first_96_lm15(16,:)))/(max(first_96_lm15(16,:))-min(first_96_lm15(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm15);
per_normalday_cm15 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm15);   
elf3_pcm15 = mod(t_sel_cm15(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm15);   
elf4_pcm15 = mod(t_sel_cm15(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm15);    
lux_pcm15 = mod(t_sel_cm15(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm15);
per_normalday_lm15 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm15);    
elf3_plm15 = mod(t_sel_lm15(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm15);   
elf4_plm15 = mod(t_sel_lm15(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_lm15);    
lux_plm15 = mod(t_sel_lm15(b(end)),24)



%
close all

%
% Photoperiod = " 18 "
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 18;      
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm18 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm18 = [0:0.1:96];                    
first_96_cm18 = deval(gen_sol_po_cm18, t_sel_cm18);

% "min-max normalization" of simulations
norm_lhy_sim_cm18 = (first_96_cm18(1,:)-min(first_96_cm18(1,:)))/(max(first_96_cm18(1,:))-min(first_96_cm18(1,:)));       % po: post-optimization
norm_elf3_sim_cm18 = (first_96_cm18(14,:)-min(first_96_cm18(14,:)))/(max(first_96_cm18(14,:))-min(first_96_cm18(14,:)));
norm_lux_sim_cm18 = (first_96_cm18(12,:)-min(first_96_cm18(12,:)))/(max(first_96_cm18(12,:))-min(first_96_cm18(12,:))); 
norm_prr73_sim_cm18 = (first_96_cm18(6,:)-min(first_96_cm18(6,:)))/(max(first_96_cm18(6,:))-min(first_96_cm18(6,:)));
norm_p5t1_sim_cm18 = (first_96_cm18(8,:)-min(first_96_cm18(8,:)))/(max(first_96_cm18(8,:))-min(first_96_cm18(8,:)));
norm_elf4_sim_cm18 = (first_96_cm18(10,:)-min(first_96_cm18(10,:)))/(max(first_96_cm18(10,:))-min(first_96_cm18(10,:)));

%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 18;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm18 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm18 = [0:0.1:96];                    
first_96_lm18 = deval(gen_sol_po_lm18, t_sel_lm18);

norm_lhy_sim_lm18 = (first_96_lm18(1,:)-min(first_96_lm18(1,:)))/(max(first_96_lm18(1,:))-min(first_96_lm18(1,:)));       % po: post-optimization
norm_elf3_sim_lm18 = (first_96_lm18(19,:)-min(first_96_lm18(19,:)))/(max(first_96_lm18(19,:))-min(first_96_lm18(19,:)));
norm_gi_sim_lm18 = (first_96_lm18(29,:)-min(first_96_lm18(29,:)))/(max(first_96_lm18(29,:))-min(first_96_lm18(29,:))); 
norm_lux_sim_lm18 = (first_96_lm18(22,:)-min(first_96_lm18(22,:)))/(max(first_96_lm18(22,:))-min(first_96_lm18(22,:))); 
norm_prr73_sim_lm18 = (first_96_lm18(8,:)-min(first_96_lm18(8,:)))/(max(first_96_lm18(8,:))-min(first_96_lm18(8,:)));
norm_p5t1_sim_lm18 = (first_96_lm18(13,:)-min(first_96_lm18(13,:)))/(max(first_96_lm18(13,:))-min(first_96_lm18(13,:)));
norm_elf4_sim_lm18 = (first_96_lm18(16,:)-min(first_96_lm18(16,:)))/(max(first_96_lm18(16,:))-min(first_96_lm18(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm18);
per_normalday_cm18 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm18);   
elf3_pcm18 = mod(t_sel_cm18(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm18);   
elf4_pcm18 = mod(t_sel_cm18(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm18);    
lux_pcm18 = mod(t_sel_cm18(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm18);
per_normalday_lm18 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm18);    
elf3_plm18 = mod(t_sel_lm18(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm18);
c = abs(t_sel_lm18(b(end))-t_sel_lm18(b(end-1)));
if c < 24 & (a(end-1)>a(end))
    elf4_plm18 = mod(t_sel_lm18(b(end-1)),24)
else
elf4_plm18 = mod(t_sel_lm18(b(end)),24)
end
% LUX
[a, b] = findpeaks(norm_lux_sim_lm18);    
lux_plm18 = mod(t_sel_lm18(b(end)),24)



%
close all

%
% Photoperiod = " 21 "
%


%
% COMPACT model 
% 
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 21;      
LDLD_or_LDLL = "LDLD";    % LDLD by default  
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";  % LDLD for photoperiods % except LDLL for const light
t_end = 96;   
gen_sol_po_cm21 = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_cm21 = [0:0.1:96];                    
first_96_cm21 = deval(gen_sol_po_cm21, t_sel_cm21);

% "min-max normalization" of simulations
norm_lhy_sim_cm21 = (first_96_cm21(1,:)-min(first_96_cm21(1,:)))/(max(first_96_cm21(1,:))-min(first_96_cm21(1,:)));       % po: post-optimization
norm_elf3_sim_cm21 = (first_96_cm21(14,:)-min(first_96_cm21(14,:)))/(max(first_96_cm21(14,:))-min(first_96_cm21(14,:)));
norm_lux_sim_cm21 = (first_96_cm21(12,:)-min(first_96_cm21(12,:)))/(max(first_96_cm21(12,:))-min(first_96_cm21(12,:))); 
norm_prr73_sim_cm21 = (first_96_cm21(6,:)-min(first_96_cm21(6,:)))/(max(first_96_cm21(6,:))-min(first_96_cm21(6,:)));
norm_p5t1_sim_cm21 = (first_96_cm21(8,:)-min(first_96_cm21(8,:)))/(max(first_96_cm21(8,:))-min(first_96_cm21(8,:)));
norm_elf4_sim_cm21 = (first_96_cm21(10,:)-min(first_96_cm21(10,:)))/(max(first_96_cm21(10,:))-min(first_96_cm21(10,:)));

%
% LARGE model 
% 

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

T=24;         % T cycle = 24 hr 
pp = 21;
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLD
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLD";
t_end = 96;
gen_sol_po_lm21 = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,pp,T,LDLD_or_LDLL),[0,t_end],init_conditions_upd); 
t_sel_lm21 = [0:0.1:96];                    
first_96_lm21 = deval(gen_sol_po_lm21, t_sel_lm21);

norm_lhy_sim_lm21 = (first_96_lm21(1,:)-min(first_96_lm21(1,:)))/(max(first_96_lm21(1,:))-min(first_96_lm21(1,:)));       % po: post-optimization
norm_elf3_sim_lm21 = (first_96_lm21(19,:)-min(first_96_lm21(19,:)))/(max(first_96_lm21(19,:))-min(first_96_lm21(19,:)));
norm_gi_sim_lm21 = (first_96_lm21(29,:)-min(first_96_lm21(29,:)))/(max(first_96_lm21(29,:))-min(first_96_lm21(29,:))); 
norm_lux_sim_lm21 = (first_96_lm21(22,:)-min(first_96_lm21(22,:)))/(max(first_96_lm21(22,:))-min(first_96_lm21(22,:))); 
norm_prr73_sim_lm21 = (first_96_lm21(8,:)-min(first_96_lm21(8,:)))/(max(first_96_lm21(8,:))-min(first_96_lm21(8,:)));
norm_p5t1_sim_lm21 = (first_96_lm21(13,:)-min(first_96_lm21(13,:)))/(max(first_96_lm21(13,:))-min(first_96_lm21(13,:)));
norm_elf4_sim_lm21 = (first_96_lm21(16,:)-min(first_96_lm21(16,:)))/(max(first_96_lm21(16,:))-min(first_96_lm21(16,:)));

%
% Calculating PHASES 

% COMPACT :  
[a, b] = findpeaks(norm_lhy_sim_cm21);
per_normalday_cm21 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_cm21);   
elf3_pcm21 = mod(t_sel_cm21(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_cm21);   
elf4_pcm21 = mod(t_sel_cm21(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_cm21);    
lux_pcm21 = mod(t_sel_cm21(b(end)),24)


% LARGE : 
[a, b] = findpeaks(norm_lhy_sim_lm21);
per_normalday_lm21 = b(end)-b(end-1)       % period 24 hr
% ELF3
[a, b] = findpeaks(norm_elf3_sim_lm21);    
elf3_plm21 = mod(t_sel_lm21(b(end)),24)
% ELF4
[a, b] = findpeaks(norm_elf4_sim_lm21);   
elf4_plm21 = mod(t_sel_lm21(b(end)),24)
% LUX
[a, b] = findpeaks(norm_lux_sim_lm21);    
lux_plm21 = mod(t_sel_lm21(b(end)),24)




%
% Fig-5A.pdf

% COMPACT model : EC complex : photoperiods 
compact_photoperiods = ["3", "6", "9", "12", "15", "18", "21"]

%elf3_pcm3 = 0.2; % corrected phase due to: findpeaks(norm_elf3_sim_cm3)

% pp phases
co_3_ec = [elf3_pcm3 elf4_pcm3 lux_pcm3]
co_6_ec = [elf3_pcm6 elf4_pcm6 lux_pcm6]          % [elf3 elf4 lux]
co_9_ec = [elf3_pcm9 elf4_pcm9 lux_pcm9]
co_12_ec = [elf3_pcm12 elf4_pcm12 lux_pcm12]
co_15_ec = [elf3_pcm15 elf4_pcm15 lux_pcm15]          % [elf3 elf4 lux]
co_18_ec = [elf3_pcm18 elf4_pcm18 lux_pcm18]
co_21_ec = [elf3_pcm21 elf4_pcm21 lux_pcm21]

pp = [1 1 1;    
    2 2 2;
    3 3 3;
    4 4 4;
    5 5 5;
    6 6 6;
    7 7 7];

plot(pp(1,1), co_3_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(1,2), co_3_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(1,3), co_3_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(2,1), co_6_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(2,2), co_6_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(2,3), co_6_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(3,1), co_9_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(3,2), co_9_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(3,3), co_9_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(4,1), co_12_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(4,2), co_12_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(4,3), co_12_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(5,1), co_15_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(5,2), co_15_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(5,3), co_15_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(6,1), co_18_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(6,2), co_18_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(6,3), co_18_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(7,1), co_21_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(7,2), co_21_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(7,3), co_21_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 
legend({'ELF3' 'ELF4' 'LUX'}, FontSize=12)

xlim([0 8]);
xticks([0, 1, 2, 3, 4, 5, 6, 7, 8]);
xticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'}); % photoperiods
ax = gca;
ax.FontSize = 18; 
xtickangle(45);
xlabel('Photoperiods (hours)', FontSize=18);
ylim([0 24]);
yticks([0, 3, 6, 9, 12, 15, 18, 21, 24]);
yticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'});
ay = gca;
ay.FontSize = 18; 
ylabel('Phases (hours from dawn)', FontSize=18);

sgtitle("Compact model (Wheat)", FontSize=18);

grid on

saveas(gcf,'Fig-5A.pdf') 





%
% Fig-5B.pdf

figure

% LARGE model : EC complex : photoperiods 

%elf4_plm18 = 16.10; % corrected phase due to: findpeaks(norm_elf4_sim_lm18)

% pp phases
la_3_ec = [elf3_plm3 elf4_plm3 lux_plm3]
la_6_ec = [elf3_plm6 elf4_plm6 lux_plm6]          % [elf3 elf4 lux]
la_9_ec = [elf3_plm9 elf4_plm9 lux_plm9]
la_12_ec = [elf3_plm12 elf4_plm12 lux_plm12]
la_15_ec = [elf3_plm15 elf4_plm15 lux_plm15]          % [elf3 elf4 lux]
la_18_ec = [elf3_plm18 elf4_plm18 lux_plm18]
la_21_ec = [elf3_plm21 elf4_plm21 lux_plm21]

pp = [1 1 1;    
    2 2 2;
    3 3 3;
    4 4 4;
    5 5 5;
    6 6 6;
    7 7 7];

plot(pp(1,1), la_3_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(1,2), la_3_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(1,3), la_3_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(2,1), la_6_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(2,2), la_6_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(2,3), la_6_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(3,1), la_9_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(3,2), la_9_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on 
plot(pp(3,3), la_9_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(4,1), la_12_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(4,2), la_12_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(4,3), la_12_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(5,1), la_15_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(5,2), la_15_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(5,3), la_15_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(6,1), la_18_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(6,2), la_18_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(6,3), la_18_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 

plot(pp(7,1), la_21_ec(1), 'o', 'MarkerSize',15, 'MarkerFaceColor','b', 'MarkerEdgeColor','b')
hold on 
plot(pp(7,2), la_21_ec(2), 's', 'MarkerSize',15, 'MarkerFaceColor','k', 'MarkerEdgeColor','k')
hold on
plot(pp(7,3), la_21_ec(3), 'v', 'MarkerSize',15, 'MarkerFaceColor','r', 'MarkerEdgeColor','r')
hold on 
%legend({'ELF3' 'ELF4' 'LUX'}, FontSize=12)

xlim([0 8]);
xticks([0, 1, 2, 3, 4, 5, 6, 7, 8]);
xticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'}); % photoperiods
ax = gca;
ax.FontSize = 18; 
xtickangle(45);
xlabel('Photoperiods (hours)', FontSize=18);
ylim([0 24]);
yticks([0, 3, 6, 9, 12, 15, 18, 21, 24]);
yticklabels({'0' '3' '6' '9' '12' '15' '18' '21' '24'});
ay = gca;
ay.FontSize = 18; 
ylabel('Phases (hours from dawn)', FontSize=18);

sgtitle("Large model (Wheat)", FontSize=18);

grid on

saveas(gcf,'Fig-5B.pdf') 




