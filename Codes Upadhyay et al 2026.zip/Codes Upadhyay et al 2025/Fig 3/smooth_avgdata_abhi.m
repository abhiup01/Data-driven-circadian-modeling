function new_matrix = smooth_avgdata(og_matrix,colms2mod)

new_matrix = og_matrix;

for col = colms2mod  % columns to be modified
        
        smooth_var_avg = smooth(new_matrix(:,1), ...  % pick x which is time point (2nd col) of corresponding replicate (1st col, e.g. r=1)
        new_matrix(:,col),0.35,'loess');     % pick y which is the col (col, e.g. 3) of corresponding replicate (r=1)

        new_matrix(:,col) = smooth_var_avg;

    end

    new_matrix(new_matrix(:,col) < 0,col) = 0;                     % replace any negative value by 0
   
end
    
