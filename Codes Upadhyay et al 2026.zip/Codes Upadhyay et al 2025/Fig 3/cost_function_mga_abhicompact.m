function cost = cost_function_mga_abhicompact(data_in,data_in_tr,times_i,sol_i,var_correspond_wt)
% Objective/Cost Function for the Genetic Algorithm
% 2 objectives: minimise the mean square difference between experimental
% and simulated peaks from wt data/model; barrier function to ensure the clock keeps
% oscillating enough 

% data_in = experimental data on peak timings
% times_i = 
% sol_i = 
% var_correspond 'or' var_correspond_wt= 

objective_pk = [];  % total 6: for all 6 variables 

samplingtime=times_i(2)-times_i(1);

for  var = var_correspond_wt(2,:)   % 5: as many common variables
    obj_pk = 0;

    % Get data corresponding to a specific clock component/variable from
    % experimental and model data
    corr_v_ind = var_correspond_wt(1,var_correspond_wt(2,:) == var);
    sub_data = data_in(data_in(:,1) == corr_v_ind,:);
    sim_data = sol_i(:,var);
%    sim_data = smooth(times_i,sol_i(:,var),5,'loess'); 

    %% Peak Timings
    [~,peaks_wheat] = findpeaks(sim_data);
    peak_times_sim = times_i(peaks_wheat);
    %plot(times_i,sim_data,times_i(peaks_wheat),sim_data(peaks_wheat),'o')

    peak_times_sim2=[];
    for i=1:1:size(peaks_wheat,1),
      if times_i(peaks_wheat(i))<96,
        flag=0;
        window=uint8(floor(7/samplingtime)); % Check windows of 7 hours 
        for j=peaks_wheat(i)-window:1:peaks_wheat(i)+window,
          if j>1 & (j+1)<size(sim_data,1)
            % Check if there is local minima
            if sim_data(j-1)>sim_data(j) & sim_data(j)<sim_data(j+1)
              flag=flag+1;
            end
          end
        end
        if   flag<2
          % Considered as peak if less than 1 local minimum found nearby
          peak_times_sim2=[peak_times_sim2; times_i(peaks_wheat(i))];
        else
          % Otherwise give penalty 
          obj_pk=obj_pk+5;
        end
      end
    end

    % Find the absolute difference in peak timings between simulated and experimental data
    peak_diffs = [];   % as many values as variables (5 in compact model wt case)
    if size(peak_times_sim2,1)>0
      % total number of peaks for given variable
      for p = 1:size(sub_data,1)
          % find distance between 2 closest peaks (1 from simulation, other from experiment)
          [~,c_p_ind] = min(abs(peak_times_sim2 - sub_data(p,2))); 
          closest_peak = peak_times_sim2(c_p_ind);
          p_diff = abs(closest_peak - sub_data(p,2)); % absolute difference
          peak_diffs = [peak_diffs,p_diff];
      end
      % get average diff timings of all peaks for a given variable
      if sub_data(p,2)<24
        if var == 14
          obj_pk = obj_pk+6*mean(peak_diffs); %put more weight on elf3 
        else
          obj_pk = obj_pk+3*mean(peak_diffs); %put more weight on LD than LL
        end
      else
        obj_pk = obj_pk+1*mean(peak_diffs); 
      end
    else
      % give penalty if simulation does not produce any peak
      obj_pk = obj_pk+100;
    end
    % collect differences for all genes
    objective_pk = [objective_pk,obj_pk];
end

objective_tr = [];  % total 5: for all 5 variables 
for  var = [var_correspond_wt(2,2:3) var_correspond_wt(2,6)] % only for elf3, lux, elf4
    corr_v_ind = var_correspond_wt(1,var_correspond_wt(2,:) == var);
    sub_data = data_in_tr(data_in_tr(:,1) == corr_v_ind,:);
    sim_data = sol_i(:,var);
%    sim_data = smooth(times_i,sol_i(:,var),5,'loess'); 

    % Find trough timings
    [~,troughs_wheat] = findpeaks(1 - sim_data);
    trough_times_sim = times_i(troughs_wheat);
    trough_times_sim2 = [];
    obj_tr = 0;
    for i=1:1:size(troughs_wheat,1),
      if times_i(troughs_wheat(i))<96,
        flag=0;
        window=uint8(floor(7/samplingtime)); % Check windows of 7 hours 
        for j=troughs_wheat(i)-window:1:troughs_wheat(i)+window,
          if j>1 & (j+1)<size(sim_data,1)
            % Check if there is local maxima
            if sim_data(j-1)<sim_data(j) & sim_data(j)>sim_data(j+1)
              flag=flag+1;
            end
          end
        end
        if flag<2
          % Considered as trough if less than 1 local maximum found nearby
          trough_times_sim2=[trough_times_sim2; times_i(troughs_wheat(i))];
        else
          % Otherwise give penalty 
          obj_tr=obj_tr+5;
        end
      end
    end

    trough_diffs = []; % as many values as variables (5 in compact model wt case)
    if size(trough_times_sim2,1)>0
      % total number of troughs for given variable
      for p = 1:3 %1:size(sub_data,1)
        % find distance between 2 closest troughs (1 from simulation, other from experiment)
        [~,c_t_ind] = min(abs(trough_times_sim2(:) - sub_data(p,2))); 
        closest_trough = trough_times_sim2(c_t_ind);
        t_diff = abs(closest_trough - sub_data(p,2)); % absolute difference
        trough_diffs = [trough_diffs,t_diff];
      end
      % get average diff timings of all troughs for a given variable
      if sub_data(p,2)<24
        if var == 14
          obj_tr = obj_tr+6*mean(trough_diffs);  %put more weight on elf3
        else
          obj_tr = obj_tr+3*mean(trough_diffs);  %put more weight on LD than LL
        end
      else
        obj_tr = obj_tr+1*mean(trough_diffs); 
      end
    else
      % give penalty if simulation does not produce any trough
      obj_tr = obj_tr+100;
    end
    % collect differences for all genes
    objective_tr = [objective_tr,obj_tr];
end

%% Keep LHY/clock oscillating
% get data from the final 12h of simulations
[~,end_12_from] = min(abs(times_i - (times_i(end)-12))); 
% get dy/dt between end time point and 12h before - gradient 
% should not be 0 if oscillating, 
% for LHY = 1, ELF3 =14 in compact model, ELF3 =16 in large model
dycond_dt = (sol_i(end,14)-sol_i(end_12_from,14))/12; 
% if it is 0, means it can still be plugged into cost 
% function without causing a math error 
dycond_dt_term = abs(dycond_dt) + 10^-70; 
% goes "exponteital only when gradient is VERY close to 0" 
% aka the clock has stopped oscillating. 
cost_osc = abs((1/6)*(-log(dycond_dt_term))); 

 
% Keep period constrained not as free running period 
[a, b] = findpeaks(sol_i(:,1));
if size(b,1)>2
  if cost_osc<1.0
    per_lhy = (times_i(b(end))-times_i(b(end-1)));
  else
    per_lhy = 0;  
  end
else
  per_lhy = 0;  
end
% calculate from LHY: variable 1; if wildtype in LL is 25 hr in wheat 
cost_per = abs(per_lhy - 24);  %%Modified from 25 h to 24 h

cost_oscper = cost_osc + 0.05*cost_per;

% FINAL cost function with 2 objectives
% cost(1) = sum(objective_pk) & cost(2) = cost_osc ; both are to be minimised 
cost = [sum(objective_pk)+sum(objective_tr), cost_oscper]; 
%cost = [cost_oscper, sum(objective_pk)+sum(objective_tr)]; 

end
