%% Experimental data (WT)
% New FINAL cost function with Isao (inclides peaks for all variables, troughs for elf3, elf4, lux)
clear all
close all

% Import Experimental Data

[webb_data_wt_avg data_in data_in_tr] = WebDataCompact();

% Webb experimental data (in black)
% "min-max normalization" of data
%norm_data = (data-min(data))/(max(data)-min(data))
raw_lhy = (webb_data_wt_avg(:,2));  % replace webb_data_wt_avg(:,2) in plot
raw_elf3 = (webb_data_wt_avg(:,3));
raw_gi = (webb_data_wt_avg(:,4));
raw_lux = (webb_data_wt_avg(:,5)); 
raw_prr73 = (webb_data_wt_avg(:,6));
raw_p5t1 = (webb_data_wt_avg(:,7));
raw_elf4 = (webb_data_wt_avg(:,5)); % substituted by lux


%norm_data = (data-min(data))/(max(data)-min(data))
norm_lhy = (webb_data_wt_avg(:,2)-min(webb_data_wt_avg(:,2)))/(max(webb_data_wt_avg(:,2))-min(webb_data_wt_avg(:,2))); % replace webb_data_wt_avg(:,2) in plot
norm_elf3 = (webb_data_wt_avg(:,3)-min(webb_data_wt_avg(:,3)))/(max(webb_data_wt_avg(:,3))-min(webb_data_wt_avg(:,3)));
norm_gi = (webb_data_wt_avg(:,4)-min(webb_data_wt_avg(:,4)))/(max(webb_data_wt_avg(:,4))-min(webb_data_wt_avg(:,4)));
norm_lux = (webb_data_wt_avg(:,5)-min(webb_data_wt_avg(:,5)))/(max(webb_data_wt_avg(:,5))-min(webb_data_wt_avg(:,5))); 
norm_prr73 = (webb_data_wt_avg(:,6)-min(webb_data_wt_avg(:,6)))/(max(webb_data_wt_avg(:,6))-min(webb_data_wt_avg(:,6)));
norm_p5t1 = (webb_data_wt_avg(:,7)-min(webb_data_wt_avg(:,7)))/(max(webb_data_wt_avg(:,7))-min(webb_data_wt_avg(:,7)));
norm_elf4 = (webb_data_wt_avg(:,5)-min(webb_data_wt_avg(:,5)))/(max(webb_data_wt_avg(:,5))-min(webb_data_wt_avg(:,5))); %substituted by lux



%
% COMPACT model 
% 

% Compact Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

% OPTIMIZED set 
a02 = [3.0959    0.5959    1.9810    0.0649    6.4184    2.8719    2.3107    3.1417    0.6955    2.7495]; %BEST optimized final set Isao
selected = 1;
parms([7,18,59,60,61,62:65,67]) = a02(selected,:);
parms(39)=1*parms(39);

LD_cyc = "Long Day";   % "Long Day"
LDLD_or_LDLL = "LDLD"; % "LDLD"
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";  % "LDLL"
t_end = 96;
gen_sol_po = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96 = deval(gen_sol_po, t_sel);


% Compact model simualtions (in green)
lhy_sim_com = (first_96(1,:));       % po: post-optimization
elf3_sim_com = (first_96(14,:));
lux_sim_com = (first_96(12,:)); 
prr73_sim_com = (first_96(6,:));
p5t1_sim_com = (first_96(8,:));
elf4_sim_com = (first_96(10,:));
elf3p_sim_com = (first_96(15,:)); % ELF3 protein


% "min-max normalization" of simulations
norm_lhy_sim_com = (first_96(1,:)-min(first_96(1,:)))/(max(first_96(1,:))-min(first_96(1,:)));       % po: post-optimization
norm_elf3_sim_com = (first_96(14,:)-min(first_96(14,:)))/(max(first_96(14,:))-min(first_96(14,:)));
norm_lux_sim_com = (first_96(12,:)-min(first_96(12,:)))/(max(first_96(12,:))-min(first_96(12,:))); 
norm_prr73_sim_com = (first_96(6,:)-min(first_96(6,:)))/(max(first_96(6,:))-min(first_96(6,:)));
norm_p5t1_sim_com = (first_96(8,:)-min(first_96(8,:)))/(max(first_96(8,:))-min(first_96(8,:)));
norm_elf4_sim_com = (first_96(10,:)-min(first_96(10,:)))/(max(first_96(10,:))-min(first_96(10,:)));
norm_elf3p_sim_com = (first_96(15,:)-min(first_96(15,:)))/(max(first_96(15,:))-min(first_96(15,:))); % ELF3 protein
%perturb_norm_elf3p_sim_com = (first_96(15,:)-min(first_96(15,:)))/(max(first_96(15,:))-min(first_96(15,:))); % ELF3 protein


% "min-max normalization" of simulations
% norm_lhy_sim_com = first_96(1,:);
% norm_elf3_sim_com = first_96(14,:);
% norm_lux_sim_com = first_96(12,:);
% norm_prr73_sim_com = first_96(6,:);
% norm_p5t1_sim_com = first_96(8,:);
% norm_elf4_sim_com = first_96(10,:);
% norm_elf3p_sim_com = first_96(15,:);



% 
% LARGE model 
% 
% Wheat circadian clock 

% Import Experimental Data for Large model
[webb_data_wt_avg data_in data_in_tr] = WebDataLarge();

% Large Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

var_correspond_wt = [2:8;1,19,29,22,8,13,16];

a03 = [0.3598	0.1876	1*1.0731	0.3561	2.3097	0.7723	0.1466	0.5692	27.6647]; % FINAL best optimal  41:1.0731
selected = 1; %BEST 
parms([7,37,41,95,96,119,120,121,122]) = a03(selected,:);  % BEST optimal para set


LD_cyc = "Long Day";   % "Long Day"
LDLD_or_LDLL = "LDLD"; % "LDLD"
t_end = 480; % 480
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL"; % "LDLL"
t_end = 96;  % 96
gen_sol_po = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96 = deval(gen_sol_po, t_sel);

% LARGE model simulations
lhy_sim_lar = (first_96(1,:));       % po: post-optimization
elf3_sim_lar = (first_96(19,:));
gi_sim_lar = (first_96(29,:)); 
lux_sim_lar = (first_96(22,:)); 
prr73_sim_lar = (first_96(8,:));
p5t1_sim_lar = (first_96(13,:));
elf4_sim_lar = (first_96(16,:));
elf3p_sim_lar = (first_96(20,:));    % ELF3 protein

% "min-max normalization" of mRNA simulations
norm_lhy_sim_lar = (first_96(1,:)-min(first_96(1,:)))/(max(first_96(1,:))-min(first_96(1,:)));       % po: post-optimization
norm_elf3_sim_lar = (first_96(19,:)-min(first_96(19,:)))/(max(first_96(19,:))-min(first_96(19,:)));
norm_gi_sim_lar = (first_96(29,:)-min(first_96(29,:)))/(max(first_96(29,:))-min(first_96(29,:))); 
norm_lux_sim_lar = (first_96(22,:)-min(first_96(22,:)))/(max(first_96(22,:))-min(first_96(22,:))); 
norm_prr73_sim_lar = (first_96(8,:)-min(first_96(8,:)))/(max(first_96(8,:))-min(first_96(8,:)));
norm_p5t1_sim_lar = (first_96(13,:)-min(first_96(13,:)))/(max(first_96(13,:))-min(first_96(13,:)));
norm_elf4_sim_lar = (first_96(16,:)-min(first_96(16,:)))/(max(first_96(16,:))-min(first_96(16,:)));
norm_elf3p_sim_lar = (first_96(20,:)-min(first_96(20,:)))/(max(first_96(20,:))-min(first_96(20,:)));
%perturb_norm_elf3p_sim_lar = (first_96(20,:)-min(first_96(20,:)))/(max(first_96(20,:))-min(first_96(20,:)));
norm_cop1pc_sim_lar = (first_96(24,:)-min(first_96(24,:)))/(max(first_96(24,:))-min(first_96(24,:)));
norm_cop1pn_sim_lar = (first_96(25,:)-min(first_96(25,:)))/(max(first_96(25,:))-min(first_96(25,:)));
norm_cop1d_sim_lar = (first_96(26,:)-min(first_96(26,:)))/(max(first_96(26,:))-min(first_96(26,:)));


% FIG-3 FINAL (normalized: wt simulations for compact and large and data)

% define panel background (for Long Day 16:8 24 hrs -> LL 72 hrs
% merge subplots using tiledlayout

tiledlayout(2,3)

nexttile
grayColor1 = [.6 .6 .6];   % gray for dark/night
grayColor2 = [.9 .9 .9];   % lighter gray for subjective night
hours1 = 1:24;  % 24 hrs
hours2 = 25:96; % 72 hrs
% (change panelx  panely's non zero value to match with ymax)
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_lhy_sim_com,'g-', 'LineWidth',2)
hold on
plot(t_sel, norm_lhy_sim_lar,'b-', 'LineWidth',2)
hold on 
plot(webb_data_wt_avg(:,1), norm_lhy,':o','Color','k', 'LineWidth',2)
legend({'','','compact','large', 'data'}, FontSize=12)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('LHY_{mRNA}');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);
%sgtitle("wild type: simulations and experiment (16:8 to LL)");

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_prr73_sim_com,'g-', 'LineWidth',2)
hold on
plot(t_sel, norm_prr73_sim_lar,'b-', 'LineWidth',2)
hold on
plot(webb_data_wt_avg(:,1), norm_prr73,':o','Color','k', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('PRR73_{mRNA}');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_p5t1_sim_com,'g-', 'LineWidth',2)
hold on
plot(t_sel, norm_p5t1_sim_lar,'b-', 'LineWidth',2)
hold on
plot(webb_data_wt_avg(:,1), norm_p5t1,':o','Color','k', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('TOC1_{mRNA}');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_gi_sim_lar,'b-', 'LineWidth',2)
hold on
plot(webb_data_wt_avg(:,1), norm_gi,':o','Color','k', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('GI_{mRNA}');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
hold on
[x,y] = stairs(hours2, panel2); 
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_lux_sim_com,'g-', 'LineWidth',2)
hold on
plot(t_sel, norm_lux_sim_lar,'b-', 'LineWidth',2)
hold on
plot(webb_data_wt_avg(:,1), norm_lux,':o','Color','k', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('LUX_{mRNA}');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1); % 2 2 2 2 2 2 2 2
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3); % 3 3 3 3 3 3 3 3
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
hold on
[x,y] = stairs(hours2, panel2); 
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_elf3_sim_com,'g-', 'LineWidth',2)
hold on
plot(t_sel, norm_elf3_sim_lar,'b-', 'LineWidth',2)
hold on
plot(webb_data_wt_avg(:,1), norm_elf3,':o','Color','k', 'LineWidth',2)
xlim([0 96]);
%legend({'','','','caluwe'}, FontSize=12)
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('ELF3_{mRNA}');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

saveas(gcf,'Fig-3.pdf')






