function [webb_data_wt_avg data_in data_in_tr] = WebDataCompact() 

%% Import Experimental Data

% in this section "function" named "smooth_avgdata_abhi.m" is called

webb_data_wt = readtable("webb_data_wt.csv"); 
webb_mat_wt = table2array(webb_data_wt);     % can use class() to know datatype
%disp(webb_mat_wt);

% average of replicates (wildtype)
webb_data_wt_avg = zeros(length(unique(webb_mat_wt(:,2))), length(3:8));
i = 1;
for j = 0:3:96
  webb_data_wt_avg(i, 1:6) = mean(webb_mat_wt(webb_mat_wt(:,2) == j,[3:8]));
  i = i+1;
end 

newcol(1:33,1) = [0:3:96];
webb_data_wt_avg = [newcol(1:33,1), webb_data_wt_avg];

% Transform data by smoothing it, makes peaks and troughs in component oscilations easier to identify
% Smoothing on avg (mean) data
webb_smooth_wt_avg = smooth_avgdata_abhi(webb_data_wt_avg,[2:7]);

% removing GI gene's column not present in compact model
w_wt_small = webb_smooth_wt_avg;
w_wt_small(:,4) = [];
%disp(w_wt_small)

%% Extracting Peak Timings for Model Fitting 

% peaks_wt or data_in is the data of note
% column 1 = variable (2 = LHY, 3 = ELF3, 4 = LUX, 5 = PRR73, 6 = TOC1, 7 = ELF4(LUX))
% column 2 = peak timing 

%mat = zeros(1,length(2:6));
%i = 1;
%for v = 2:6
%    [~,tt] = findpeaks(w_wt_small(:,v));
%    num_peak = length(tt);
%    mat(i) = num_peak;
%    i = i + 1;
%end 
      
peaks_wt = [];

for v = 2:7
    period_diffs = [];
    if(v == 7)  % LUX data is used for ELF4
      sub_data = [w_wt_small(:,1), w_wt_small(:,4)];
    else
      sub_data = [w_wt_small(:,1), w_wt_small(:,v)];
    end
    [~,p_t] = findpeaks(sub_data(:,2));
    peak_timings = sub_data(p_t,1);
    if(v == 0)                     % peak timing 0 in LHY manually added
        peak_timings = [0;peak_timings]; % earlier it was 0 not 2
    end

    if(v == 0)                     % peak timing 0 in PRR73 manually added
        peak_timings = [0;peak_timings];  % earlier it was 0 not 4 
    end

    mat_add = zeros(length(peak_timings),2);
    mat_add(:,1) = v;
    mat_add(:,2) = peak_timings;

    peaks_wt = [peaks_wt;mat_add];  % column 1 & column 2
end

% variable 2:7 in exp data & 1,14,12,6,8,10 corresponding var in simulation in order
% as in exp % earlier % var_correspond_wt = [2:6;1,14,12,6,8];
% 1: experiment: 2 = LHY,  3 = ELF3,  4 = LUX, 5 = PRR73, 6 = TOC1, 7 = ELF4(LUX)
% 2: simulation: 1 = LHY, 14 = ELF3, 12 = LUX, 6 = PRR73, 8 = TOC1, 10 = ELF4
var_correspond_wt = [2:7;1,14,12,6,8,10];

data_in = peaks_wt;

%disp(data_in);


% mat_t = zeros(1);   % zeros(1,length(2:6));
% i = 1;
% for v = 3
%         [~,tt] = findpeaks(1- w_wt_small(:,v));
%         num_trough = length(tt);
%         mat_t(i) = num_trough;
%         i = i + 1;
% end 
      
troughs_wt = [];

for v = 2:7
    period_diffs = [];
    if(v == 7)  % LUX data is used for ELF4
      sub_data = [w_wt_small(:,1), w_wt_small(:,4)];
    else
      sub_data = [w_wt_small(:,1), w_wt_small(:,v)];
    end  
    [~,t_t] = findpeaks(1- sub_data(:,2));

    trough_timings = sub_data(t_t,1);

    mat_add = zeros(length(trough_timings),2);  % column 1st: variable, 2nd: trough timing 
    mat_add(:,1) = v;
    mat_add(:,2) = trough_timings;

    troughs_wt = [troughs_wt; mat_add];  % column 1 & column 2 & column 3
end

% variable 2:7 in exp data & 1,14,12,6,8,10 corresponding var in simulation in order
% as in exp % earlier % var_correspond_wt = [2:6;1,14,12,6,8];
% 1: experiment: 2 = LHY,  3 = ELF3,  4 = LUX, 5 = PRR73, 6 = TOC1, 7 = ELF4(LUX)
% 2: simulation: 1 = LHY, 14 = ELF3, 12 = LUX, 6 = PRR73, 8 = TOC1, 10 = ELF4
var_correspond_wt = [2:7;1,14,12,6,8,10];

data_in_tr = troughs_wt;

%disp(data_in_tr);      % elf3 trough times: 12, 36, 60


%%
% manually modify the elf3 trough based on raw data (non-smoothed)

% findpeaks(webb_data_wt_avg(:,3));
% hold on 
% findpeaks(1 - webb_data_wt_avg(:,3));
% [elf3_t1,elf3_raw] = findpeaks(1 - webb_data_wt_avg(:,3))
% 
% findpeaks(w_wt_small(:,3));
% hold on 
% findpeaks(1 - w_wt_small(:,3));
% [elf3_t2,elf3_smo] = findpeaks(1 - w_wt_small(:,3))

% manually trough times: (7*3-3)=18, (16*3-3)=45, (24*3-3)=69
data_in_tr(4,2) = 18;
data_in_tr(5,2) = 45;
data_in_tr(6,2) = 69;
%disp(data_in_tr);      % manually modified elf3 trough times: 18, 45, 69

% manually peak times: (9*3-3)=18, (17*3-3)=48, (25*3-3)=69
% [elf3_t3,elf3_rawpeaks] = findpeaks(webb_data_wt_avg(:,3))
data_in(4,2) = 24;  % same
data_in(5,2) = 48;
data_in(6,2) = 72;
%disp(data_in);     % manually modified elf3 peak times: 24, 48, 72

end
