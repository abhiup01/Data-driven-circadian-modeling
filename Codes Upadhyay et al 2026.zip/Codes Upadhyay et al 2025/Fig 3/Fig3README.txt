# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs parameter optimisation, data analysis, model simulations and visualization for Figure 3.


## Usage
Run the main script in wheat_wt_compact_large_simulations.m in MATLAB.


## Features
- Custom visualization tools
- Supports CSV data formats
- Experimental data (webb_data_wt.csv) processing for example, smoothing of oscillatory data using smooth_avgdata_abhi.m
- Two wheat clock models (compact and large) equations are written in wheat_wt_compact_abhi.m and wheat_large_abhi.m 
- Model's parameters and variable's initial conditions are called from CompactModel_Parameters_InitialCond.m and LargeModel_Parameters_InitialCond.m
- Experimental and simulations peaks and troughs are calculated for compact and large models, in WebDataCompact.m and WebDataLarge.m, respectively.  
- Cost functions for both models are written in cost_function_mga_abhicompact.m and cost_function_mga_abhilarge
- Parameter optimisation using gamultiobj package is performed for both models in parms_test_ga_abhicompact and parms_test_ga_abhilarge


## Output
Fig-3.pdf showing an optimised wheat models which capture transcript abundance dynamics of key clock genes is generated.

 
