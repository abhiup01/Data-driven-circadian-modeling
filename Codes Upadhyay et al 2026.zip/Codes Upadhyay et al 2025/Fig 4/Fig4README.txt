# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs model simulations for Figure 4.


## Usage
Run the main script in fig4plot_simulations.m in MATLAB.


## Features
- Experimental data (webb_data_wt.csv) processing For example, smoothing of oscillatory data using smooth_avgdata_abhi.m
- Two wheat clock models (compact and large) equations are written in wheat_wt_compact_abhi.m and wheat_large_abhi.m 
- Model's parameters and variable's initial conditions are called from CompactModel_Parameters_InitialCond.m and LargeModel_Parameters_InitialCond.m
- Experimental and simulations peaks and troughs for compact and large models are taken from WebDataCompact.m and WebDataLarge.m, respectively.  


## Output
Fig-4A.pdf and Fig-4B.pdf showing that TOC1 repression of ELF3 is required for correct timing of ELF3 expression under (A) wild type and (B) TOC1 removal on ELF3 condition are generated.

 
