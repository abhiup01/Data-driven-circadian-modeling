# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs arabidopsis models simulations for Figure 1C.


## Usage
Run the main script in Arabidopsis_Simulations.m in MATLAB.


## Features
- Custom visualization tools
- Two Arabidopsis models (de Caluwé 2016 and Fogelmark 2014) are written in arabidopsis_caluwe.m and arabidopsis_fogelmark.m


## Output
Fig-1C.pdf showing model simulations of Arabidopsis EC mRNA is generated.

 
