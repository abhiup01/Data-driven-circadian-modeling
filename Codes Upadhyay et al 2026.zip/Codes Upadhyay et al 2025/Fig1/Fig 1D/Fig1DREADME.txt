# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs experimental data visualization for Figure 1D.


## Usage
Run the main script in circadian_polarplot.m in MATLAB.


## Features
- Custom visualization tools
- Data points for ELF3, and LUX mRNA expression for various cereals are collected and mentioned in circadian_polarplot.m


## Output
Fig-1D.pdf showing measured peak phases of ELF3 and LUX transcripts among various cereals is generated.

 
