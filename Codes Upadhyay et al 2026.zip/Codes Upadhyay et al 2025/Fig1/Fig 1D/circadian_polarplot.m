% circadian_polarplot figure 

clear all
close all
% cereals                    		    ELF3 	-  	LUX
%1: Bromes (Brachypodium distachyon)  22.6469	-	11.5154
%2: Maize			                  21.4228	-	  -
%3: Millet 			                  20.3890   -     -
%4: Rice (Oryza sativa)			      20.2788 	-	12.8470
%5: Sorghum 			              23.6144	-	  -

% non-cereals removed
%Poplar (Populus trichocarpa)     15.7440	-	13.1996  % non-cereal
%Soybean			              15.3640	-	15.0350  % non-cereal


rho_elf3   = [1          2         3         4          5];
theta_elf3 = [2*pi*22.6469/24 2*pi*21.4228/24 2*pi*20.3890/24 2*pi*20.2788/24 2*pi*23.6144/24];
rho_lux    = [1          4];
theta_lux  = [2*pi*11.5154/24 2*pi*12.8470/24];

%polarplot(theta_elf3,rho_elf3,'or','MarkerFaceColor','r','MarkerSize',10)
polarplot(theta_elf3,rho_elf3,'ob','LineWidth',2,'MarkerSize',10)
hold on
polarplot(theta_lux,rho_lux,'^r','LineWidth',2,'MarkerSize',10)
legend({'ELF3','LUX'},'Location','northwest')
%legend('boxoff')

rlim([0 5])
rticks([1:1:5])
rticklabels({'Bromes (Brachypodium distachyon)','Maize','Millet',...
  'Rice (Oryza sativa)', 'Sorghum'})
thetaticks(0:45:315)
thetaticklabels({'ZT0','ZT3','ZT6','ZT9','ZT12','ZT15','ZT18','ZT21'})
%thetaticklabels(0:3:24)
title('mRNA expression peaks')
pax = gca;
pax.FontSize = 15;
pax.RAxis.FontSize = 10;
pax = gca;
pax.ThetaAxisUnits = 'radians';
%pax.ThetaDir = 'counterclockwise';
pax.ThetaDir = 'clockwise';
%pax.ThetaZeroLocation = 'left';
pax.ThetaZeroLocation = 'top';
rtickangle(pax,0);
%rtickangle(pax,-15);
%pax.ThetaColor = 'blue';
%pax.RColor = [0 .5 0];

saveas(gcf,'Fig1D.pdf')


