%% Arabidopsis Mockler data extracted from http://diurnal.mocklerlab.org/diurnal_data_finders
% https://www.arabidopsis.org/servlets/TairObject?type=locus&name=at2g25930
clear all

% LONG DAY experiment
t_sel = [0:4:44];
elf3_exp_moc = [93.94 25.55 107.88 210.41 235.71 205.51 107.65 27.40 120.57 221.73 237.32 256.03] ; % AT2G25930
elf4_exp_moc = [28.16 19.42 344.93 714.75 318.84 102.31 22.45 25.86 327.96 808.34 460.53 98.23]; % AT2G40080
lux_exp_moc = [27.65 15.62 205.40 334.57 205.78 43.73 22.89 10.20 149.59 339.66 195.88 72.95]; % AT3G46640

% ELF3 mRNA (normalized)
norm_elf3_exp_moc = (elf3_exp_moc-min(elf3_exp_moc))/(max(elf3_exp_moc)-min(elf3_exp_moc));
% ELF4 mRNA
norm_elf4_exp_moc = (elf4_exp_moc-min(elf4_exp_moc))/(max(elf4_exp_moc)-min(elf4_exp_moc));
% LUX mRNA
norm_lux_exp_moc = (lux_exp_moc-min(lux_exp_moc))/(max(lux_exp_moc)-min(lux_exp_moc));


%
% Plot Fig 1A

tiledlayout(1,1)

nexttile
grayColor1 = [.6 .6 .6];   % gray for dark/night
%grayColor2 = [.6 .6 .6];   % lighter gray for subjective night
hours1 = 1:24;  % 24 hrs
%hours2 = 25:48; % 24 hrs
% (change panelx  panely's non zero value to match with ymax)
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
%[x,y] = stairs(hours2, panel2); 
%hold onå
%area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, norm_elf3_exp_moc,'-o','Color','b', 'LineWidth',6)
hold on
plot(t_sel, norm_elf4_exp_moc,'-o','Color','k', 'LineWidth',6)
hold on
plot(t_sel, norm_lux_exp_moc,'-o','Color','r', 'LineWidth',6)
hold on
legend({'','ELF3', 'ELF4', 'LUX'}, FontSize=12)
xlim([0 24]);
xticks([0 12 24]);
xticklabels({'0' '12' '24'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 24;ax.YAxis.FontSize = 24;
ylabel({'mRNA expression';'(normalized)'});xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);
sgtitle("{\it Arabidopsis} experimental data", FontSize=24); % wild type: Arabidopsis experiment (Mockler data, Long day)

saveas(gcf,'Fig-1A.pdf')





