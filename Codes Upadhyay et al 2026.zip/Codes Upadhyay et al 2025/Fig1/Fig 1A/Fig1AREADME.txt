# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs arabidopsis experimental data visualization for Figure 1A.


## Usage
Run the main script in Arabidopsis_Experiments.m in MATLAB.


## Features
- Custom visualization tools
- Supports .xlsx data formats
- Data points for ELF3, ELF4 and LUX mRNA expression are collected from (Mockler et al. 2007) datasets http://diurnal.mocklerlab.org/diurnal_data_finders and are called in Arabidopsis_Experiments.m


## Output
Fig-1A.pdf showing measured dynamics of wild type Arabidopsis transcripts encoding evening complex proteins is generated.

 
