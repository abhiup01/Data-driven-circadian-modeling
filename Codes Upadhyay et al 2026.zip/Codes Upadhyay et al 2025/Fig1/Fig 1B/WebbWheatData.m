clear all
close all

% Import Experimental Data

[webb_data_wt_avg data_in data_in_tr] = WebDataCompact();


% Webb experimental data (only EC complex: ELF3, LUX available, not ELF4)
% "min-max normalization" of data
%norm_data = (data-min(data))/(max(data)-min(data))
norm_elf3 = (webb_data_wt_avg(:,3)-min(webb_data_wt_avg(:,3)))/(max(webb_data_wt_avg(:,3))-min(webb_data_wt_avg(:,3)));
norm_lux = (webb_data_wt_avg(:,5)-min(webb_data_wt_avg(:,5)))/(max(webb_data_wt_avg(:,5))-min(webb_data_wt_avg(:,5))); 


% Plot Fig 1B

tiledlayout(1,1)

nexttile
grayColor1 = [.6 .6 .6];   % gray for dark/night
grayColor2 = [.9 .9 .9];   % lighter gray for subjective night
hours1 = 1:24;  % 24 hrs
%hours2 = 25:96; % 72 hrs
% (change panelx  panely's non zero value to match with ymax)
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
%panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
%[x,y] = stairs(hours2, panel2); 
%hold on
%area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(webb_data_wt_avg(:,1), norm_elf3,'-o','color','b', 'LineWidth',6)
hold on
plot(webb_data_wt_avg(:,1), norm_lux,'-o','color','r', 'LineWidth',6)
hold on 
legend({'','ELF3 (wheat)', 'LUX (wheat)'}, FontSize=12)
xlim([0 24]);
xticks([0 12 24]);
xticklabels({'0' '12' '24'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 24;ax.YAxis.FontSize = 24;
ylabel({'transcript abundance';'(normalized)'});xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);
sgtitle("Wheat experimental data", FontSize=24); % wild type: Webb wheat data (16:8 to LL)


saveas(gcf,'Fig-1B.pdf')



