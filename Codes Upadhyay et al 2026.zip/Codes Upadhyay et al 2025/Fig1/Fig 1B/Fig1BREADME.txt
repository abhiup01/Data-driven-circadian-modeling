# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs wheat experimental data visualization for Figure 1B.


## Usage
Run the main script in WebbWheatData.m in MATLAB.


## Features
- Custom visualization tools
- Supports CSV data formats
- Experimental data (webb_data_wt.csv) processing for example, smoothing of oscillatory data using smooth_avgdata_abhi.m
- Experimental data of Wittern et al. 2023 are presented in WebDataCompact.m   


## Output
Fig-1B.pdf showing measured dynamics of TtELF3 and TtLUX transcript abundance is generated.

 
