# MyProject
Data-driven mathematical modelling explains altered timing of EARLY FLOWERING 3 in wheat circadian oscillators


## Description
This MATLAB project performs data analysis, model simulations and visualization for Figure 6.


## Usage
Run the main script in fig6_simulations_mutantnormalizedwt.m in MATLAB.


## Features
- Custom visualization tools
- Supports CSV data formats
- Experimental wild type and mutant data (webb_data_wt.csv and webb_data_mut.csv) processing for example, smoothing of oscillatory data using smooth_avgdata_abhi.m
- Two wheat clock models (compact and large) equations are written in wheat_wt_compact_abhi.m and wheat_large_abhi.m 
- Model's parameters and variable's initial conditions are called from CompactModel_Parameters_InitialCond.m and LargeModel_Parameters_InitialCond.m
- Experimental peaks and troughs are taken from WebDataCompact.m   


## Output
Fig-6.pdf showing wheat model simulations in the elf3 mutant background is generated.

 
