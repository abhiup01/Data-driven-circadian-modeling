function [parms init_cond_wt] = CompactModel_Parameters_InitialCond() 

%% Compact Model (FINAL VERSION ABHI)

% Parameters
parms(1) = 4.58;
parms(2) = 3.0; 
parms(3) = 1.27;
parms(4) = 0.5;
parms(5) = 5.0;
parms(6) = 1.0;
parms(7) = 1.1;   % v3A: elf3 basal trasncription % was missing earlier
parms(8) = 1.1;
parms(9) = 1;
parms(10) = 2; 

parms(11) = 0.53;
parms(12) = 0.21;
parms(13) = 0.35;
parms(14) = 0.56;
parms(15) = 0.57;
parms(16) = 0.4;
parms(17) = 0.4;
parms(18) = 0.5;   % k7: elf3 degradation 

parms(19) = 0.76;
parms(20) = 0.42;
parms(21) = 1.01;
parms(22) = 0.64;
parms(23) = 0.22; 
parms(24) = 0.6;
parms(25) = 0.6;
parms(26) = 0.8;   % elf3 mutant related p7 elf3 prot prod
parms(27) = 0.68;
parms(28) = 0.5;
parms(29) = 0.29; 
parms(30) = 0.48; 
parms(31) = 0.38;
parms(32) = 1.2; 
parms(33) = 0.38; 
parms(34) = 0.5;
parms(35) = 0.8;
parms(36) = 0.5;
parms(37) = 0.8;
parms(38) = 0.7;
parms(39) = 0.7;
parms(40) = 0.6;

parms(41) = 2.80;
parms(42) = 0.16; 
parms(43) = 1.18;
parms(44) = 0.5;
parms(45) = 0.2; 
parms(46) = 0.23; 
parms(47) = 0.63; 
parms(48) = 1.73; 
parms(49) = 0.46;
parms(50) = 0.5; 
parms(51) = 0.6;
parms(52) = 0.3;
parms(53) = 1.9;
parms(54) = 0.3;
parms(55) = 0.5;
parms(56) = 2.0;
parms(57) = 0.3;
parms(58) = 0.5;
parms(59) = 2.0;   % K16
parms(60) = 0.8;    % K17
parms(61) = 1.9;

parms(62) = 1;     % w1
parms(63) = 0.7;   % w2
parms(64) = 0.35;  % w3
parms(65) = 0.2;   % w4
parms(66) = 1;
parms(67) = 3;     % w6

% Initialise Variables (% new ic from Jamila)
LHYm_init = 1;
LHYp_init = 1;
Pp_init = 1;
P95m_init = 0.1;
P95p_init = 0.4;
P73m_init = 0.3;
P73p_init = 0.3;
P5T1m_init = 0.1;
P5T1p_init = 0.1;
E4m_init = 0.1;
E4p_init = 0.1;
LUXm_init = 0.1;
LUXp_init = 0.1;
E3m_init = 0.3;
E3p_init = 0.3;
EC_init = 0.3;

init_cond_wt = [LHYm_init,LHYp_init,Pp_init,P95m_init,P95p_init,P73m_init,P73p_init,P5T1m_init,P5T1p_init,E4m_init,E4p_init,LUXm_init,LUXp_init,E3m_init,E3p_init,EC_init];

end



