%% Import WT Experimental Data
clear all
close all

[webb_data_wt_avg data_in data_in_tr] = WebDataCompact();


%
% Import MUTANT Experimental Data

webb_data_mut = readtable("webb_data_mut.csv"); 
webb_mat_mut = table2array(webb_data_mut);     % can use class() to know datatype
disp(webb_mat_mut);

% average of replicates (wildtype)
webb_data_mut_avg = zeros(length(unique(webb_mat_mut(:,2))), length(3:8));
for i =1
for j = 0:3:96
        webb_data_mut_avg(i, 1:6) = mean(webb_mat_mut(webb_mat_mut(:,2) == j,[3:8]));
        i = i +1
end 
end
newcol(1:33,1) = [0:3:96];
webb_data_mut_avg = [newcol(1:33,1), webb_data_mut_avg];
webb_data_mut_avg;
webb_data_mut_avg(15,3) = 0.6000;
webb_data_mut_avg(11,4) = 2.5000;


% to normalize mutant data: mut-min(mut)/max(wt)-min(wt)
elf3mut_norm_lhy = (webb_data_mut_avg(:,2)-min(webb_data_mut_avg(:,2)))/(max(webb_data_wt_avg(:,2))-min(webb_data_wt_avg(:,2))); 
elf3mut_norm_elf3 = (webb_data_mut_avg(:,3)-min(webb_data_mut_avg(:,3)))/(max(webb_data_wt_avg(:,3))-min(webb_data_wt_avg(:,3)));
elf3mut_norm_gi = (webb_data_mut_avg(:,4)-min(webb_data_mut_avg(:,4)))/(max(webb_data_wt_avg(:,4))-min(webb_data_wt_avg(:,4)));
elf3mut_norm_lux = (webb_data_mut_avg(:,5)-min(webb_data_mut_avg(:,5)))/(max(webb_data_wt_avg(:,5))-min(webb_data_wt_avg(:,5))); 
elf3mut_norm_prr73 = (webb_data_mut_avg(:,6)-min(webb_data_mut_avg(:,6)))/(max(webb_data_wt_avg(:,6))-min(webb_data_wt_avg(:,6)));
elf3mut_norm_p5t1 = (webb_data_mut_avg(:,7)-min(webb_data_mut_avg(:,7)))/(max(webb_data_wt_avg(:,7))-min(webb_data_wt_avg(:,7)));


%
% Compact Model (WT)
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

parms([7,18,59,60,61,62:65,67]) = [2.8459    0.3459    2.2310    0.0649    6.1684    3.1219    2.0607    2.6417    0.9455    2.7495];  % optimal para set Isao

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";
t_end = 96;
gen_sol_po_comwt = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96_comwt = deval(gen_sol_po_comwt, t_sel);


% Compact Model ("MUTANT")
% Compact Model (FINAL VERSION ABHI)
[parms_og init_cond_wt] = CompactModel_Parameters_InitialCond();
parms=parms_og;

% OPTIMIZED set 
a02 = [2.8459    0.3459    2.2310    0.0649    6.1684    3.1219    2.0607    2.6417    0.9455    2.7495]; %BEST optimized final set Isao
selected = 1;
parms([7,18,59,60,61,62:65,67]) = a02(selected,:);

% elf3 MUTANT part 
parms(26)=0.005*parms(26);      % elf3 prot prod rate; original=0.8; p7=0 or p7=0.005*p7

parm_og = parms;
parms = parm_og;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";
t_end = 96;
gen_sol_po = ode15s(@(t,vars)wheat_wt_compact_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96 = deval(gen_sol_po, t_sel);

% normalized mutant to wt
elf3mut_norm_lhy_sim_4 = (first_96(1,:)-min(first_96(1,:)))/(max(first_96_comwt(1,:))-min(first_96_comwt(1,:))); 
elf3mut_norm_elf3_sim_4 = (first_96(14,:)-min(first_96(14,:)))/(max(first_96_comwt(14,:))-min(first_96_comwt(14,:)));
elf3mut_norm_elf4_sim_4 = (first_96(10,:)-min(first_96(10,:)))/(max(first_96_comwt(10,:))-min(first_96_comwt(10,:)));
elf3mut_norm_lux_sim_4 = (first_96(12,:)-min(first_96(12,:)))/(max(first_96_comwt(12,:))-min(first_96_comwt(12,:))); 
elf3mut_norm_prr73_sim_4 = (first_96(6,:)-min(first_96(6,:)))/(max(first_96_comwt(6,:))-min(first_96_comwt(6,:)));
elf3mut_norm_p5t1_sim_4 = (first_96(8,:)-min(first_96(8,:)))/(max(first_96_comwt(8,:))-min(first_96_comwt(8,:)));


%
% Large Model (WT)
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

a03 = [0.3598	0.1876	1.0731	0.3561	2.3097	0.7723	0.1466	0.5692	27.6647];
selected = 1; %BEST 
parms([7,37,41,95,96,119,120,121,122]) = a03(selected,:);  % optimal para set

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";
t_end = 96;
gen_sol_po_larwt = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96_larwt = deval(gen_sol_po_larwt, t_sel);

% Large Model ("elf3 MUTANT")
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

a03 = [0.3598	0.1876	1.0731	0.3561	2.3097	0.7723	0.1466	0.5692	27.6647]; % FINAL best optimal: cost1= 204 cost2=0.0027
selected = 1; %BEST 
parms([7,37,41,95,96,119,120,121,122]) = a03(selected,:);  % BEST optimal para set
% elf3 MUTANT at translational level
parms(68)=0.005*parms(68);        % elf3 prot prod p16; original= 0.4024; p16=0 or 0.005*p16

parm_og = parms;
parms = parm_og;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";
t_end = 96;
gen_sol_po = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96 = deval(gen_sol_po, t_sel);

% mut to wt max normalized 
elf3mut_norm_lhy_sim_la_4 = (first_96(1,:)-min(first_96(1,:)))/(max(first_96_larwt(1,:))-min(first_96_larwt(1,:)));       % po: post-optimization
elf3mut_norm_elf3_sim_la_4 = (first_96(19,:)-min(first_96(19,:)))/(max(first_96_larwt(19,:))-min(first_96_larwt(19,:)));
elf3mut_norm_gi_sim_la_4 = (first_96(29,:)-min(first_96(29,:)))/(max(first_96_larwt(29,:))-min(first_96_larwt(29,:))); 
elf3mut_norm_lux_sim_la_4 = (first_96(22,:)-min(first_96(22,:)))/(max(first_96_larwt(22,:))-min(first_96_larwt(22,:))); 
elf3mut_norm_prr73_sim_la_4 = (first_96(8,:)-min(first_96(8,:)))/(max(first_96_larwt(8,:))-min(first_96_larwt(8,:)));
elf3mut_norm_p5t1_sim_la_4 = (first_96(13,:)-min(first_96(13,:)))/(max(first_96_larwt(13,:))-min(first_96_larwt(13,:)));
elf3mut_norm_elf4_sim_la_4 = (first_96(16,:)-min(first_96(16,:)))/(max(first_96_larwt(16,:))-min(first_96_larwt(16,:)));


% Large Model ("elf3 MUTANT")-I
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

a03 = [0.3598	0.1876	1.0731	0.3561	2.3097	0.7723	0.1466	0.5692	27.6647]; % FINAL best optimal: cost1= 204 cost2=0.0027
selected = 1; %BEST 
parms([7,37,41,95,96,119,120,121,122]) = a03(selected,:);  % BEST optimal para set
% elf3 MUTANT at translational level
parms(68)=0.01*parms(68);        % elf3 prot prod p16; original= 0.4024; p16

parm_og = parms;
parms = parm_og;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";
t_end = 96;
gen_sol_po = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96 = deval(gen_sol_po, t_sel);

% mut to wt max normalized 
elf3mut_norm_lhy_sim_la_4_1 = (first_96(1,:)-min(first_96(1,:)))/(max(first_96_larwt(1,:))-min(first_96_larwt(1,:)));       % po: post-optimization
elf3mut_norm_elf3_sim_la_4_1 = (first_96(19,:)-min(first_96(19,:)))/(max(first_96_larwt(19,:))-min(first_96_larwt(19,:)));
elf3mut_norm_gi_sim_la_4_1 = (first_96(29,:)-min(first_96(29,:)))/(max(first_96_larwt(29,:))-min(first_96_larwt(29,:))); 
elf3mut_norm_lux_sim_la_4_1 = (first_96(22,:)-min(first_96(22,:)))/(max(first_96_larwt(22,:))-min(first_96_larwt(22,:))); 
elf3mut_norm_prr73_sim_la_4_1 = (first_96(8,:)-min(first_96(8,:)))/(max(first_96_larwt(8,:))-min(first_96_larwt(8,:)));
elf3mut_norm_p5t1_sim_la_4_1 = (first_96(13,:)-min(first_96(13,:)))/(max(first_96_larwt(13,:))-min(first_96_larwt(13,:)));
elf3mut_norm_elf4_sim_la_4_1 = (first_96(16,:)-min(first_96(16,:)))/(max(first_96_larwt(16,:))-min(first_96_larwt(16,:)));


% Large Model ("elf3 MUTANT")-II
[parms_og init_cond_wt] = LargeModel_Parameters_InitialCond();
parms=parms_og;

a03 = [0.3598	0.1876	1.0731	0.3561	2.3097	0.7723	0.1466	0.5692	27.6647]; % FINAL best optimal: cost1= 204 cost2=0.0027
selected = 1; %BEST 
parms([7,37,41,95,96,119,120,121,122]) = a03(selected,:);  % BEST optimal para set
% elf3 MUTANT at translational level
parms(68)=0.005*parms(68);        % elf3 prot prod p16; original= 0.4024; p16

parm_og = parms;
parms = parm_og;

LD_cyc = "Long Day"; 
LDLD_or_LDLL = "LDLD"; 
t_end = 480; 
[~,v_wheatwt_ldld] = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_cond_wt);
init_conditions_upd = v_wheatwt_ldld(end,:);
% Run LDLL
% FULL FINAL PLOT ("Post-optimization")
LDLD_or_LDLL = "LDLL";
t_end = 96;
gen_sol_po = ode15s(@(t,vars)wheat_large_abhi(t,vars,parms,LDLD_or_LDLL,LD_cyc),[0,t_end],init_conditions_upd); % gen sol post-optim
t_sel = [0:1:96];                    
first_96 = deval(gen_sol_po, t_sel);

% mut to wt max normalized 
elf3mut_norm_lhy_sim_la_4_2 = (first_96(1,:)-min(first_96(1,:)))/(max(first_96_larwt(1,:))-min(first_96_larwt(1,:)));       % po: post-optimization
elf3mut_norm_elf3_sim_la_4_2 = (first_96(19,:)-min(first_96(19,:)))/(max(first_96_larwt(19,:))-min(first_96_larwt(19,:)));
elf3mut_norm_gi_sim_la_4_2 = (first_96(29,:)-min(first_96(29,:)))/(max(first_96_larwt(29,:))-min(first_96_larwt(29,:))); 
elf3mut_norm_lux_sim_la_4_2 = (first_96(22,:)-min(first_96(22,:)))/(max(first_96_larwt(22,:))-min(first_96_larwt(22,:))); 
elf3mut_norm_prr73_sim_la_4_2 = (first_96(8,:)-min(first_96(8,:)))/(max(first_96_larwt(8,:))-min(first_96_larwt(8,:)));
elf3mut_norm_p5t1_sim_la_4_2 = (first_96(13,:)-min(first_96(13,:)))/(max(first_96_larwt(13,:))-min(first_96_larwt(13,:)));
elf3mut_norm_elf4_sim_la_4_2 = (first_96(16,:)-min(first_96(16,:)))/(max(first_96_larwt(16,:))-min(first_96_larwt(16,:)));


% Fig-5 (normalzied: elf3 mutant simulations for compact and large with mutant data)

tiledlayout(2,3)

nexttile
grayColor1 = [.6 .6 .6];   % gray for dark/night
grayColor2 = [.9 .9 .9];   % lighter gray for subjective night
hours1 = 1:24;  % 24 hrs
hours2 = 25:96; % 72 hrs
% (change panelx  panely's non zero value to match with ymax)
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, elf3mut_norm_lhy_sim_4,'g-', 'LineWidth',2)
hold on
plot(t_sel, elf3mut_norm_lhy_sim_la_4,'b-', 'LineWidth',2)
hold on 
plot(webb_data_mut_avg(:,1), elf3mut_norm_lhy,':o','Color','r', 'LineWidth',2)
legend({'','','compact (p7=0.005*p7)','large (p16=0.005*p16)','mutant data'}, FontSize=12)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('LHY_{mRNA} (normalized)');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);
%sgtitle("elf3 mutant: simulations and experiment (16:8 to LL) normalzied (mut-min)/wt(max-min) p7=0*p7,p16=0.01*p16");

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, elf3mut_norm_prr73_sim_4,'g-', 'LineWidth',2)
hold on
plot(t_sel, elf3mut_norm_prr73_sim_la_4,'b-', 'LineWidth',2)
hold on
plot(webb_data_mut_avg(:,1), elf3mut_norm_prr73,':o','Color','r', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('PRR73_{mRNA} (normalized)');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 4 4 4 4 4 4 4],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 4 4 4 4 4 4 4],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, elf3mut_norm_p5t1_sim_4,'g-', 'LineWidth',2)
hold on
plot(t_sel, elf3mut_norm_p5t1_sim_la_4,'b-', 'LineWidth',2)
hold on
plot(webb_data_mut_avg(:,1), elf3mut_norm_p5t1,':o','Color','r', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('TOC1_{mRNA} (normalized)');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
[x,y] = stairs(hours2, panel2); 
hold on
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, elf3mut_norm_gi_sim_la_4,'b-', 'LineWidth',2)
hold on
plot(webb_data_mut_avg(:,1), elf3mut_norm_gi,':o','Color','r', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('GI_{mRNA} (normalized)');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5],1,1);
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.5 1.5 1.5 1.5 1.5 1.5 1.5 1.5],1,3);
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
hold on
[x,y] = stairs(hours2, panel2); 
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, elf3mut_norm_lux_sim_4,'g-', 'LineWidth',2)
hold on
plot(t_sel, elf3mut_norm_lux_sim_la_4,'b-', 'LineWidth',2)
hold on
plot(webb_data_mut_avg(:,1), elf3mut_norm_lux,':o','Color','r', 'LineWidth',2)
xlim([0 96]);
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('LUX_{mRNA} (normalized)');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

nexttile
grayColor1 = [.6 .6 .6];   
grayColor2 = [.9 .9 .9];   
hours1 = 1:24;  
hours2 = 25:96; 
panel1 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2],1,1); % 2 2 2 2 2 2 2 2
panel2 = repmat([0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1.2 1.2 1.2 1.2 1.2 1.2 1.2 1.2],1,3); % 3 3 3 3 3 3 3 3
[x,y] = stairs(hours1, panel1);
area(x,y,'edgecolor','none','facecolor',grayColor1);
hold on
[x,y] = stairs(hours2, panel2); 
area(x,y,'edgecolor','none','facecolor',grayColor2); 
set(gca,'color','w')
hold on
plot(t_sel, elf3mut_norm_elf3_sim_4,'g-', 'LineWidth',2)
hold on
plot(t_sel, elf3mut_norm_elf3_sim_la_4,'b-', 'LineWidth',2)
hold on
plot(webb_data_mut_avg(:,1), elf3mut_norm_elf3,':o','Color','r', 'LineWidth',2)
xlim([0 96]);
%legend({'','','','caluwe'}, FontSize=12)
xticks([0 24 48, 72, 96]);
xticklabels({'0' '24' '48' '72' '96'});
ax=gca; ax.LineWidth=2;ax.FontWeight = 'normal';ax.XAxis.FontSize = 12;ax.YAxis.FontSize = 12;
ylabel('ELF3_{mRNA} (normalized)');xlabel('time (h)');
set(gcf,'color','w');
set(gca,'TickLength',[0,0]);

saveas(gcf,'Fig-6.pdf')





